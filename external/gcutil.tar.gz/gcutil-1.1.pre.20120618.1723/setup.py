#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Setup script for the Google Compute Engine command-line tool."""



from gcutil import version
try:
  from setuptools import setup
  print 'Loaded setuptools'
except ImportError:
  from distutils.core import setup
  print 'Loaded distutils.core'


PACKAGE_NAME = 'google-compute-client'
INSTALL_REQUIRES = ['google-apputils==0.3.0',
                    'google-api-python-client==1.0c1',
                    'httplib2==0.7.4',
                    'iso8601==0.1.4',
                    'python-gflags==2.0']

setup(name=PACKAGE_NAME,
      version=version.__version__,
      description='Google Compute Engine command line tool',
      author='Google Inc.',
      author_email='gc-team@google.com',
      url='http://code.google.com/p/google-compute-client/',
      install_requires=INSTALL_REQUIRES,
      packages=['gcutil'],
      package_data={'gcutil': [
          'compute/v1beta11.json',
          'compute/v1beta12.json',
          ]},
      scripts=['gcutil/gcutil'],
      license='Apache 2.0',
      keywords='google compute engine client',
      classifiers=['Development Status :: 3 - Alpha',
                   'Intended Audience :: Developers',
                   'License :: OSI Approved :: Apache Software License',
                   'Operating System :: POSIX',
                   'Topic :: Internet :: WWW/HTTP'])
