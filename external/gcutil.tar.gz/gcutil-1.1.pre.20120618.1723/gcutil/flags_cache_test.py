#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for the flags cache."""



import gflags as flags
import unittest

from gcutil.flags_cache import FlagsCache


class FlagsCacheTest(unittest.TestCase):
  """Test cases for the FlagsCache class."""

  def setUp(self):
    self.flag_values = flags.FlagValues()
    flags.DEFINE_string('string_flag_without_default',
                        None,
                        'Test string flag without default value',
                        flag_values=self.flag_values)
    flags.DEFINE_string('string_flag_with_default',
                        'Default value 1',
                        'Test string flag with a default value',
                        flag_values=self.flag_values)
    flags.DEFINE_string('parsed_string_flag_without_default',
                        None,
                        'Test, parsed string flag without default value',
                        flag_values=self.flag_values)
    flags.DEFINE_string('parsed_string_flag_with_default',
                        'Default value 2',
                        'Test, parsed string flag with a default value',
                        flag_values=self.flag_values)
    flags.DEFINE_bool('bool_flag_without_default',
                      None,
                      'Test boolean flag without default value',
                      flag_values=self.flag_values)
    flags.DEFINE_bool('bool_flag_with_default',
                      True,
                      'Test boolean flag with default value',
                      flag_values=self.flag_values)
    flags.DEFINE_bool('parsed_bool_flag_without_default',
                      None,
                      'Test, parsed boolean flag without default value',
                      flag_values=self.flag_values)
    flags.DEFINE_bool('parsed_bool_flag_with_default',
                      True,
                      'Test, parsed boolean flag with default value',
                      flag_values=self.flag_values)
    test_argv = ['command-name',
                 '--parsed_string_flag_without_default=value1',
                 '--parsed_string_flag_with_default=value2',
                 '--parsed_bool_flag_without_default=True',
                 '--parsed_bool_flag_with_default=False']
    self.flag_values(test_argv)

  def testGetCacheableFlagValues(self):
    cacheable_flags = FlagsCache._GetCacheableFlagValues(self.flag_values)
    self.assertTrue('string_flag_without_default' in cacheable_flags)
    self.assertTrue('parsed_string_flag_without_default' in cacheable_flags)
    self.assertTrue('bool_flag_without_default' in cacheable_flags)
    self.assertTrue('parsed_bool_flag_without_default' in cacheable_flags)
    self.assertFalse('string_flag_with_default' in cacheable_flags)
    self.assertFalse('parsed_string_flag_with_default' in cacheable_flags)
    self.assertFalse('bool_flag_with_default' in cacheable_flags)
    self.assertFalse('parsed_bool_flag_with_default' in cacheable_flags)

  def testGetParsedFlagValues(self):
    parsed_flags = FlagsCache._GetParsedFlagValues(self.flag_values)
    self.assertTrue('parsed_string_flag_without_default' in parsed_flags)
    self.assertTrue('parsed_string_flag_with_default' in parsed_flags)
    self.assertTrue('parsed_bool_flag_without_default' in parsed_flags)
    self.assertTrue('parsed_bool_flag_with_default' in parsed_flags)
    self.assertFalse('string_flag_without_default' in parsed_flags)
    self.assertFalse('string_flag_with_default' in parsed_flags)
    self.assertFalse('bool_flag_without_default' in parsed_flags)
    self.assertFalse('bool_flag_with_default' in parsed_flags)

  def testGetCachedFlagValuesFromString(self):
    cacheable_flags = FlagsCache._GetCacheableFlagValues(self.flag_values)
    parsed_flags = FlagsCache._GetParsedFlagValues(cacheable_flags)
    cache_string = ('--string_flag_without_default=Default Value 1\n'
                    '--unknown_flag=Some meaningless value\n'
                    '--parsed_string_flag_without_default=Default Value 2\n'
                    '--bool_flag_without_default=True\n')
    cached_flags = FlagsCache._GetCachedFlagValuesFromString(
        cacheable_flags, parsed_flags, cache_string)
    self.assertEquals(cached_flags.string_flag_without_default,
                      'Default Value 1')
    self.assertTrue(cached_flags.bool_flag_without_default)
    self.assertFalse('parsed_string_flag_without_default' in cached_flags)
    self.assertFalse('parsed_bool_flag_without_default' in cached_flags)

  def testGetCanonicalFlagValuesFromString(self):
    cache_string = ('--string_flag_without_default=Cached Value 1\n'
                    '--parsed_string_flag_without_default=Cached Value 2\n'
                    '--bool_flag_without_default=True\n')
    canonical_flags = FlagsCache._GetCanonicalFlagValuesFromString(
        self.flag_values, cache_string)
    self.assertEquals(canonical_flags.string_flag_without_default,
                      'Cached Value 1')
    self.assertEquals(canonical_flags.parsed_string_flag_without_default,
                      'value1')
    self.assertTrue(canonical_flags.bool_flag_without_default)
    self.assertTrue(canonical_flags.parsed_bool_flag_without_default)


if __name__ == '__main__':
  unittest.main()
