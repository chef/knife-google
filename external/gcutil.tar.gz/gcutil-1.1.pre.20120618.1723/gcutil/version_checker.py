#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""A module that can check for new versions.

Clients of this module can check for a new version by
invoking version_checker.IsNewVersionAvailable().

This module checks for new versions by visiting VERSION_INFO_URL which
should contain the latest version info in JSON like:

{
 "version": "1.1.pre.20120206.1750",
 "package_name": "gcutil-1.1.pre.20120206.1750.tar.gz"
}

Once a check is made, the results are cached in the file specified by
VERSION_CACHE_FILE. All subsequent calls on
version_checker.IsNewVersionAvailable() use the cached values. The
cache is updated once it becomes older than MAX_CACHE_AGE.
"""



import datetime
import json
import logging
import os
import socket

import httplib2
import iso8601
import pytz

import gflags as flags

from gcutil import version

LOGGER = logging.getLogger(__name__)
VERSION_INFO_URL = 'http://dl.google.com/compute/latest-version.json'
VERSION_CACHE_FILE = '~/.gcutil.version'
SETUP_DOC_URL = 'https://developers.google.com/compute/docs/gcutil_setup'
TIMEOUT_IN_SEC = 1

# The minimum amount of time that can pass between visits to
# VERSION_INFO_URL to grab the latest version string.
MAX_CACHE_AGE = datetime.timedelta(days=1)

FLAGS = flags.FLAGS

flags.DEFINE_boolean('check_for_new_version',
                     True,
                     'Check for new version.')


class VersionChecker(object):
  """Facilitates the discovery of new versions."""

  def __init__(self,
               cache_file,
               current_version=version.__version__,
               datetime_obj=datetime.datetime,
               httplib_obj=None):
    """Initializes a new instance of VersionChecker.

    Args:
      cache_file: A file-like object that is used for caching the latest
          version string.
      current_version: The current version string.
      datetime_obj: An object that should have a now() method that
          represents the datetime at invocation using a datetime.datetime
          object.
      httplib_obj: An object that has a request() method which behaves like
          httplib2.Http's request() method.
    """
    self.cache_file = cache_file

    cache_contents = self.cache_file.read()
    if cache_contents:
      self.cache = json.loads(cache_contents)
    else:
      self.cache = {}

    self.current_version = current_version
    self.datetime_obj = datetime_obj
    self.httplib_obj = httplib_obj or httplib2.Http(timeout=TIMEOUT_IN_SEC)

  def _DownloadVersionInfoJson(self):
    """Fetches the latest version information.

    The version information is available at the URL specified in
    VERSION_INFO_URL. If the URL cannot be reached within one second,
    a warning message is logged and None is returned.

    Raises:
      HttpLib2Error: If there is a problem accessing the URL (including a
          latency of more than a second).

    Returns:
      The latest version string or None if there was a problem fetching
          the version string.
    """
    try:
      _, contents = self.httplib_obj.request(VERSION_INFO_URL)
      return contents
    except (httplib2.HttpLib2Error, socket.timeout):
      LOGGER.warning('Could not get latest version information '
                     'because %s was unreachable.' % (VERSION_INFO_URL))
      raise

  def _ParseVersionString(self, version_info_json):
    """Parses a JSON string that contains a version string.

    Args:
      version_info_json: A JSON-formatted string that
          contains a string key 'version' which contains a
          version string.

    Returns:
      The version string that is in the JSON string.

    Raises:
      ValueError: If the JSON string is malformed.
      KeyError: If the JSON string does not contain the key
          'version'.
    """
    try:
      version_info = json.loads(version_info_json)
    except ValueError:
      LOGGER.warning('The version info downloaded from %s is malformed.'
                     % (VERSION_INFO_URL))
      raise

    if 'version' not in version_info:
      LOGGER.warning('The version info downloaded from %s does not contain '
                     'key \'version\'' % (VERSION_INFO_URL))
      raise KeyError

    return version_info['version']

  def _UpdateCache(self, latest_version):
    """Updates the cache with the given version string.

    Args:
      latest_version: The version string to cache.
    """
    self.cache['latest_version'] = latest_version
    self.cache['current_version'] = self.current_version
    self.cache['last_check_time'] = self.datetime_obj.now(
        tz=pytz.UTC).isoformat()

    self.cache_file.seek(0)
    self.cache_file.truncate()
    json.dump(self.cache, self.cache_file)
    self.cache_file.flush()

  def _CacheNeedsUpdate(self):
    """Returns True if the cache needs to be updated.

    The cache must be updated if the version string has never been
    cached, the cached string is more than a day old, or the current
    version is higher than the cached version.
    All time information is based on the user's machine's time.

    Returns:
      Whether the cache needs to be updated, i.e., whether
          VERSION_INFO_URL needs to be visited to fetch the latest
          version string.
    """
    if not self.cache:  # Cache is empty.
      return True

    if self.cache['current_version'] != self.current_version:
      return True

    last_check_time = iso8601.parse_date(self.cache['last_check_time'])
    if self.datetime_obj.now(tz=pytz.UTC) - last_check_time > MAX_CACHE_AGE:
      return True

    return False

  def IsNewVersionAvailable(self):
    """Returns True if a new version is available.

    Returns False if a new version is not available or if it cannot be
    determined whether a new version is available.

    Returns:
      Whether a new version is available.
    """
    if self._CacheNeedsUpdate():
      try:
        latest_version = self._ParseVersionString(
            self._DownloadVersionInfoJson())
      except (KeyError, ValueError, httplib2.HttpLib2Error, socket.timeout):
        return False

      self._UpdateCache(latest_version)

    return self.cache['latest_version'] != self.current_version


def CheckForNewVersion():
  """Warns the user if there is a new version available."""
  if not FLAGS.check_for_new_version:
    return

  try:
    cache_loc = os.path.expanduser(VERSION_CACHE_FILE)

    if os.path.exists(cache_loc):
      file_mode = 'r+'
    else:
      file_mode = 'w+'

    with open(cache_loc, file_mode) as cache_file:
      vc = VersionChecker(cache_file)
      if vc.IsNewVersionAvailable():
        LOGGER.warning('Your version of gcutil is different from the '
                       'released version. For instructions on getting the '
                       'latest version go to: %s' % SETUP_DOC_URL)
  except IOError:
    LOGGER.warning('Unable to perform version check.')
