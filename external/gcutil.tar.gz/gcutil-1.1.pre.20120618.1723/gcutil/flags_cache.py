#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cache of previously used flag values."""

from __future__ import with_statement



import copy
import os

import gflags as flags

FLAGS = flags.FLAGS

flags.DEFINE_bool(
    'cache_flag_values',
    False,
    'If true, cache all specified flag values in the file specified '
    'by the "cached_flags_file" flag.')
flags.DEFINE_string(
    'cached_flags_file',
    '~/.gcutil.flags',
    'Cache for flag values that do not have a defined default value')


class FlagsCache(object):
  """File based cache of values for flags with user-specific defaults."""

  def __init__(self, cache_file_name=None):
    cache_file_name = cache_file_name or FLAGS.cached_flags_file
    self.cache_file_path = os.path.expanduser(cache_file_name)
    if os.path.exists(self.cache_file_path):
      with open(self.cache_file_path) as cache_file:
        self.cache_string = cache_file.read()
    else:
      self.cache_string = ''

  @staticmethod
  def _GetCacheableFlagValues(flag_values):
    """Get the subset of flags that are appropriate to cache.

    This corresponds to the flags whose default value is None.

    Args:
      flag_values: The superset FlagValues object.
    Returns:
      A subset FlagValues object that contains only the cacheable flags.
    """
    cacheable_flag_values = flags.FlagValues()
    for flag in flag_values:
      if flag_values[flag].default is None:
        cacheable_flag_values[flag] = flag_values[flag]
    return cacheable_flag_values

  @staticmethod
  def _GetParsedFlagValues(flag_values):
    """Get the subset of flags that have been explicitly set.

    Args:
      flag_values: The superset FlagValues object.
    Returns:
      A subset FlagValues object that contains only the explicitly set flags.
    """
    parsed_flag_values = flags.FlagValues()
    for flag in flag_values:
      if flag_values[flag].present:
        parsed_flag_values[flag] = flag_values[flag]
    return parsed_flag_values

  @staticmethod
  def _GetCachedFlagValuesFromString(cacheable_flag_values,
                                     parsed_flag_values,
                                     cache_string):
    """Get the values for cacheable flags from the given cache string.

    Any flags in the parsed_flags argument will be omitted regardless of
    whether or not they are in the cache_string. This allows cached and
    parsed flags to be combined without conflict.

    Args:
      cacheable_flag_values: A FlagValues instance defining the cacheable flags.
      parsed_flag_values: A FlagValues instance defining the flags that
                          have been parsed from a command line and should
                          be omitted from the result.
      cache_string: The contents of the cache as a newline delimited string.
    Returns:
      A FlagValues instance containing the flags present in the cache.
    """
    cached_flag_values = flags.FlagValues()
    # We don't want to inadvertantly overwrite the parsed members of the
    # cacheable_flags, so we make a deep copy of it before appending.
    cached_flag_values.AppendFlagValues(copy.deepcopy(cacheable_flag_values))
    undefok = []
    cache_entries = cache_string.split('\n')
    while cache_entries:
      try:
        argv = (['dummy_command', '--undefok=\'%s\'' % ','.join(undefok)] +
                cache_entries)
        cache_entries = cached_flag_values(argv)[2:]
      except flags.UnrecognizedFlagError, err:
        undefok.append(err.flagname)
    cached_flag_values.RemoveFlagValues(parsed_flag_values)
    return FlagsCache._GetParsedFlagValues(cached_flag_values)

  @staticmethod
  def _GetCanonicalFlagValuesFromString(flag_values, cache_string):
    """Get the canonical set of flags given the cache string.

    If a flag is both cached and parsed, then the parsed value is used.
    Flags that are neither cached nor parsed are omitted from the
    canonical FlagValues instance.

    Args:
      flag_values: FlagValues instance containing all flags under consideration.
      cache_string: The contents of the cache as a newline delimited string.
    Returns:
      The canonical flag values.
    """
    cacheable_flag_values = FlagsCache._GetCacheableFlagValues(flag_values)
    parsed_flag_values = FlagsCache._GetParsedFlagValues(cacheable_flag_values)
    cached_flag_values = FlagsCache._GetCachedFlagValuesFromString(
        cacheable_flag_values, parsed_flag_values, cache_string)
    canonical_flag_values = flags.FlagValues()
    canonical_flag_values.AppendFlagValues(cached_flag_values)
    canonical_flag_values.AppendFlagValues(parsed_flag_values)
    return canonical_flag_values

  def SynchronizeFlags(self, flag_values=None, update_cache=None):
    """Synchronize the given FlagValues instance with this cache.

    This updates the FlagValues instance with values for any unparsed flags if
    they have an entry in the cache. If the 'update_cache' arg is True, then the
    cache will also be updated with any flags whose value is parsed.

    Args:
      flag_values: The FlagValues instance to synchronized. If not specified,
          then the global FlagValues instance is used.
      update_cache: Whether or not to update the cache file.
    Returns:
      The synchronized FlagValues instance.
    """
    if not flag_values:
      flag_values = FLAGS
    # update_cache will be set to a boolean value, so we have to explicitly
    # check if it is None rather than relying on the implicit false behavior.
    if update_cache is None:
      update_cache = flag_values.cache_flag_values
    canonical_flag_values = FlagsCache._GetCanonicalFlagValuesFromString(
        flag_values, self.cache_string)
    if update_cache:
      with open(self.cache_file_path, 'w') as cache_file:
        cache_file.write(canonical_flag_values.FlagsIntoString())
    flag_values.RemoveFlagValues(canonical_flag_values)
    flag_values.AppendFlagValues(canonical_flag_values)
    return flag_values
