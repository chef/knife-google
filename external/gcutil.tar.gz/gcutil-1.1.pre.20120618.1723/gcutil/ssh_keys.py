#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utility class for creating/storing SSH keys."""



import os
import subprocess


import gflags as flags

from gcutil import command_base


PRIVATE_KEY_FILE = 'google_compute_engine'
PUBLIC_KEY_FILE = PRIVATE_KEY_FILE + '.pub'

flags.DEFINE_string(
    'public_key_file',
    os.path.expanduser('~/.ssh/' + PUBLIC_KEY_FILE),
    'The location of the default (generated) public ssh key for use '
    'with Google Cloud Compute instances.')

flags.DEFINE_string(
    'private_key_file',
    os.path.expanduser('~/.ssh/' + PRIVATE_KEY_FILE),
    'The location of the default (generated) private ssh key for use '
    'with Google Cloud Compute instances.')

flags.DEFINE_string(
    'ssh_user',
    os.getenv('USER'),
    'The default ssh user for the instance.')

FLAGS = flags.FLAGS
LOGGER = command_base.LOGGER


class Error(Exception):
  pass


class UserSetupError(Error):
  """Raised the users environment isn't set up correctly."""

  def __init__(self, msg):
    Error.__init__(self)
    self.msg = msg

  def __str__(self):
    return self.msg


class SshKeys(object):
  """Collection of methods that work with Google Compute Engine SSH Keys."""

  @staticmethod
  def GetAuthorizedUserKeys(use_compute_key=True,
                            authorized_ssh_keys=None):
    """Get a typical list of ssh user/key dictionaries.

    Args:
      use_compute_key: authorize using ~/.ssh/compute.pub
      authorized_ssh_keys: key string user1:keyfile1,user2:keyfile2...

    Returns:
      A list of {'user': ..., 'key': ...} dictionaries.
    """
    user_keys = []

    if use_compute_key:
      user_keys.append(SshKeys.GetPublicKey())

    if authorized_ssh_keys:
      for user_key_file_pair in authorized_ssh_keys:
        user, key_file = user_key_file_pair.split(':')
        user_keys.append({'user': user,
                          'key': SshKeys.GetKeyFromFile(key_file)})
    return user_keys

  @staticmethod
  def GetAuthorizedUserKeysFromMetadata(metadata):
    """Get the set of authorized user keys from the given metadata.

    Args:
      metadata: list of {'key': ..., 'value': ...} dictionaries.
    Returns:
      A list of {'user': ..., 'key':...} dictionaries.
    """

    def GetAuthorizedUserKeyFromLine(line):
      line_parts = line.split(':')
      return {'user': line_parts[0], 'key': line_parts[1]}

    for metadata_entry in metadata:
      key = metadata_entry['key']
      value = metadata_entry['value']
      if key == 'sshKeys':
        lines = value.split('\n')
        return [GetAuthorizedUserKeyFromLine(line)
                for line in lines if ':' in line]
    return []

  @staticmethod
  def SetAuthorizedUserKeysInMetadata(metadata, authorized_user_keys):
    """Add the authorized public ssh keys to the given metadata.

    Args:
      metadata: A list of {'key': ..., 'value': ...} dictionaries.
      authorized_user_keys: A list of {'user': ..., 'key':...} dictionaries.
    Returns:
      The metadata updated to include exactly one 'sshKeys' entry that
      matches the given authorized user keys.
    """

    all_user_keys_string = '\n'.join(
        ['%(user)s:%(key)s' % user_keys for user_keys in authorized_user_keys])
    for metadata_entry in metadata:
      if metadata_entry['key'] == 'sshKeys':
        metadata_entry['value'] = all_user_keys_string
        return
    metadata.append({'key': 'sshKeys', 'value': all_user_keys_string})

  @staticmethod
  def GetPublicKey():
    """Returns the standard Compute key for the current user.

    If the key doesn't exist, it will be created and will
    interactively prompt the user.

    Returns:
      A dictionary of an user/key pair for the user's ssh key.
    """
    SshKeys.EnsurePublicKeyCreated()
    if (not FLAGS['ssh_user'].present) and FLAGS.ssh_user == 'root':
      LOGGER.warn('Logging into root is not supported on default images. '
                  'Please specify a different user account with --ssh_user. '
                  'Use this flag for addinstance and all ssh based commands.')
    return {'user': FLAGS.ssh_user,
            'key': SshKeys.GetKeyFromFile(FLAGS.public_key_file)}

  @staticmethod
  def EnsurePublicKeyCreated():
    """Ensures that the public key actually exists.

    This will create a public/private key pair if no existing
    public key is found.

    Raises:
      UserSetupError: Error when generating the ssh key
    """
    if os.path.exists(FLAGS.public_key_file):
      return

    LOGGER.warn('You don\'t have a public ssh key for Google Compute Engine. '
                'Creating one now...')
    command_line = [
        'ssh-keygen',
        '-t', 'rsa',
        '-q',
        '-f', FLAGS.private_key_file,
    ]

    LOGGER.debug(' '.join(command_line))
    try:
      process = subprocess.Popen(command_line)
      process.communicate()
      if process.wait() != 0:
        raise UserSetupError('Error generating compute ssh key.')
    except OSError as e:
      raise UserSetupError('There was a problem running ssh-keygen: %s' % e)

  @staticmethod
  def GetKeyFromFile(key_file):
    """Read an ssh key from key_file, and return it.

    Args:
      key_file: the file containing the ssh key

    Returns:
      A the ssh key stored in the file.

    Raises:
      UserSetupError: if the keyfile has too many lines.
    """
    f = open(os.path.expanduser(key_file), 'r')
    try:
      key_file_lines = [line.strip() for line in f.readlines()]
      key_file_lines = [line for line in key_file_lines if line]
      if len(key_file_lines) != 1:
        raise UserSetupError('Your key file (%s) has too many lines')

      return key_file_lines[0]
    finally:
      f.close()
