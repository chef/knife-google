#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Base command types for interacting with Google Compute Engine."""



import datetime
import httplib
import inspect
import json
import logging
import os
import re
import sys
import time
import traceback


from apiclient import discovery
from apiclient import errors
from apiclient import model

import httplib2
import iso8601
import oauth2client.client as oauth2_client
import pytz


from google.apputils import app
from google.apputils import appcommands
import gflags as flags

from gcutil import auth_helper
from gcutil import flags_cache
from gcutil import metadata_lib
from gcutil import scopes
from gcutil import version
from gcutil import table_formatter

FLAGS = flags.FLAGS
LOG_ROOT = 'gcutil-logs'
LOGGER = logging.getLogger(LOG_ROOT)

LOG_LEVELS = [logging.DEBUG,
              logging.INFO,
              logging.WARNING,
              logging.CRITICAL]

LOG_LEVEL_NAMES = map(logging.getLevelName, LOG_LEVELS)

CLIENT_ID = 'google-api-client-python-compute-cmdline/1.0'

CURRENT_VERSION = version.__default_api_version__
SUPPORTED_VERSIONS = version.__supported_api_versions__


flags.DEFINE_enum(
    'log_level',
    logging.getLevelName(logging.INFO),
    LOG_LEVEL_NAMES,
    'Logging output level for core Google Compute Engine messages.  '
    'For logging output from other libraries, use library_log_level.')
flags.DEFINE_enum(
    'library_log_level',
    logging.getLevelName(logging.WARN),
    LOG_LEVEL_NAMES,
    'Logging output level for libraries.')
flags.DEFINE_enum(
    'service_version',
    CURRENT_VERSION,
    SUPPORTED_VERSIONS,
    'Google computation service version.')
flags.DEFINE_string(
    'api_host',
    'https://www.googleapis.com/',
    'API host name')
flags.DEFINE_string(
    'project_id',
    None,
    'The name of the Google Compute Engine project.')
flags.DEFINE_bool(
    'print_json',
    False,
    'Output JSON instead of tabular format.')
flags.DEFINE_enum(
    'long_values_display_format',
    'elided',
    ['elided', 'full'],
    'The display preference for long table values.')
flags.DEFINE_string(
    'sort_by',
    None,
    'Sort output results by the given field.')
flags.DEFINE_bool(
    'fetch_discovery',
    False,
    'If true, grab the API description from the discovery API.')
flags.DEFINE_bool(
    'synchronous_mode',
    True,
    'If false, return immediately after posting a request.')
flags.DEFINE_integer(
    'sleep_between_polls',
    5,
    'The time to sleep between polls to the server in seconds.',
    1, 600)
flags.DEFINE_integer(
    'max_wait_time',
    120,
    'The maximum time to wait for an asynchronous operation to complete in '
    'seconds.',
    30, 1200)
flags.DEFINE_string(
    'trace_token',
    None,
    'Trace the API requests using a trace token provided by Google.')


class Error(Exception):
  """The base class for this tool's error reporting infrastructure."""


class CommandError(Error):
  """Raised when a command hits a general error."""


# A wrapper around an Api that adds a trace keyword to the Api.
class TracedApi(object):
  """Wrap an Api to add a trace keyword argument."""

  def __init__(self, obj, trace):
    def Wrap(func):
      def _Wrapped(*args, **kwargs):
        # Add a trace= URL parameter to the method call.
        if trace:
          kwargs['trace'] = trace
        return func(*args, **kwargs)
      return _Wrapped

    # Find all public methods and interpose them.
    for method in inspect.getmembers(obj, (inspect.ismethod)):
      if not method[0].startswith('__'):
        setattr(self, method[0], Wrap(method[1]))


class TracedComputeApi(object):
  """Wrap a ComputeApi object to return TracedApis."""

  def __init__(self, obj, trace):
    def Wrap(func):
      def _Wrapped(*args, **kwargs):
        ret = func(*args, **kwargs)
        if ret:
          ret = TracedApi(ret, trace)
        return ret
      return _Wrapped

    # Find all our public methods and interpose them.
    for method in inspect.getmembers(obj, (inspect.ismethod)):
      if not method[0].startswith('__'):
        setattr(self, method[0], Wrap(method[1]))


class GoogleComputeCommand(appcommands.Cmd):
  """Base class for commands that interact with the Google Compute Engine API.

  Overriding classes must override the SetApi and Handle methods.

  Attributes:
    GOOGLE_PROJECT_PATH: The common 'google' project used for storage of shared
        images and kernels.
    operation_detail_fields: A set of tuples of (json field name, human
        readable name) used to generate a pretty-printed detailed description
        of an operation resource.
    supported_versions: The list of API versions supported by this tool.
    safety_prompt: A boolean indicating whether the command requires user
        confirmation prior to executing.
  """

  GOOGLE_PROJECT_PATH = 'projects/google'

  operation_detail_fields = (('name', 'name'),
                             ('status', 'status'),
                             ('progress', 'progress'),
                             ('statusMessage', 'statusMessage'),
                             ('target', 'targetLink'),
                             ('target id', 'targetId'),
                             ('client operation id', 'clientOperationId'),
                             ('insertTime', 'insertTime'),
                             ('startTime', 'startTime'),
                             ('endTime', 'endTime'),
                             ('operationType', 'operationType'))

  def __init__(self, name, flag_values):
    """Initializes a new instance of a GoogleComputeCommand.

    Args:
      name: The name of the command.
      flag_values: The values of command line flags to be used by the command.
    """
    super(GoogleComputeCommand, self).__init__(name, flag_values)

    self.supported_versions = SUPPORTED_VERSIONS

    if hasattr(self, 'safety_prompt'):
      flags.DEFINE_bool('force',
                        False,
                        'Override the "%s" prompt' % self.safety_prompt,
                        flag_values=flag_values,
                        short_name='f')

    if self._IsListCommand():
      flags.DEFINE_integer('max_results',
                           None,
                           'Maximum number of items to list',
                           flag_values=flag_values)
      flags.DEFINE_string('page_token',
                          None,
                          'Token for next page of list',
                          flag_values=flag_values)
      flags.DEFINE_bool('fetch_all_pages',
                        True,
                        'Whether to fetch all pages on truncated results',
                        flag_values=flag_values)
      flags.DEFINE_string('filter',
                          None,
                          'Filter expression for filtering listed resources.',
                          flag_values=flag_values)

  def _IsListCommand(self):
    """Determine whether this is a list command.

    Returns:
      True if this is a list command, False otherwise.
    """
    return self.__class__.__name__.startswith('List')

  def _BuildListArgs(self):
    """Builds args for the list method.

    Returns:
      Dictionary of list method args.
    """
    d = {'project': self._project_id}
    if self._flags.max_results:
      d['maxResults'] = self._flags.max_results
    if self._flags.page_token:
      d['pageToken'] = self._flags.page_token
    if self._flags.filter:
      d['filter'] = self._flags.filter
    return d

  def _ReadInSelectedItem(self, menu, menu_name):
    while True:
      userinput = raw_input('>>> ').strip()
      try:
        selection = int(userinput)
        if selection in menu:
          return selection
      except ValueError:
        pass
      print 'Invalid selection, please choose one of the listed ' + menu_name

  def _PromptForEntry(self, collection_api, collection_name):
    """Prompt the user to select an entry from an API collection.

    Args:
      collection_api: The API collection wrapper.
      collection_name: The name of the collection used in building the prompts.
    Returns:
      A collection entry as selected by the user.
    """
    request = collection_api.list(project=self._project_id)
    choices = []
    while True:
      result = request.execute()
      choices.extend(result['items'])
      if not 'nextPageToken' in result:
        break
      request = collection_api.list(project=self._project_id,
                                    pageToken=result['nextPageToken'])

    choices.sort(key=lambda resource: resource['name'])
    for (i, choice) in enumerate(choices):
      short_name = choice['name'].split('/')[-1]
      print '%d: %s' % (i + 1, short_name)

    selection = self._ReadInSelectedItem(range(1, len(choices) + 1),
                                         collection_name + 's')
    return choices[selection - 1]

  def _PromptForZone(self):
    """Prompt the user to select a zone from the current list.

    Returns:
      A zone resource as selected by the user.
    """
    return self._PromptForEntry(self._zones_api, 'zone')

  def _PromptForDisk(self):
    """Prompt the user to select a disk from the current list.

    Returns:
      A disk resource as selected by the user.
    """
    return self._PromptForEntry(self._disks_api, 'disk')

  def _PromptForMachineType(self):
    """Prompt the user to select a machine type from the current list.

    Returns:
      A machine type resource as selected by the user.
    """
    return self._PromptForEntry(self._machine_types_api, 'machine type')

  def _GetZone(self, zone=None):
    """Notifies the user if the given zone will enter maintenance soon.

    The given zone can be None in which case the user is prompted for
    a zone. This method is intended to provide a warning to the user
    if he or she seeks to create a disk or instance in a zone that
    will enter maintenance in less than two weeks.

    Args:
      zone: The name of the zone chosen, or None.

    Returns:
      The given zone or the zone chosen through the prompt.
    """
    if zone is None:
      zone_resource = self._PromptForZone()
      zone = zone_resource['name']
    else:
      zone = zone.split('/')[-1]
      zone_resource = self._zones_api.get(
          project=self._project_id, zone=zone).execute()

    # Warns the user if there is an upcoming maintenance for the
    # chosen zone.
    windows = zone_resource.get('maintenanceWindows')
    if windows:
      windows = [iso8601.parse_date(win['beginTime']) for win in windows]
      next_win = min(windows)
      delta = next_win - datetime.datetime.now(tz=pytz.UTC)
      if delta < datetime.timedelta(weeks=2):
        if delta.days < 1:
          delta_text = 'less than 24 hours'
        elif delta.days == 1:
          delta_text = '1 day'
        else:
          delta_text = '%s days' % delta.days
        LOGGER.warn('%s will become unavailable for maintenance in %s.',
                    zone, delta_text)

    return zone

  def _AuthenticateWrapper(self, http):
    """Adds the OAuth token into http request.

    Args:
      http: An instance of httplib2.Http or something that acts like it.

    Returns:
      httplib2.Http like object.

    Raises:
      CommandError: If the credentials can't be found.
    """
    credential = auth_helper.GetCredentialFromStore(
        self.__GetRequiredAuthScopes())
    if not credential:
      raise CommandError(
          'Could not get valid credentials for API.')
    return credential.authorize(http)


  def _SetupLogging(self):
    """Set up a logger that will have its own logging level."""
    gc_handler = logging.StreamHandler()
    gc_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    LOGGER.addHandler(gc_handler)
    LOGGER.propagate = False

    log_level_map = dict(
        [(logging.getLevelName(level), level) for level in LOG_LEVELS])

    # Update library_log_level to INFO if user wants to see
    # dump_request_response.
    if FLAGS.dump_request_response:
      if (not FLAGS['library_log_level'].present and
          not logging.getLogger().isEnabledFor(logging.INFO)):
        FLAGS.library_log_level = 'INFO'

    LOGGER.setLevel(log_level_map[FLAGS.log_level])
    logging.getLogger().setLevel(log_level_map[FLAGS.library_log_level])

  def _ParseArgumentsAndFlags(self, flag_values, argv):
    """Parses the command line arguments for the command.

    This method matches up positional arguments based on the
    signature of the Handle method.  It also parses the flags
    found on the command line.

    argv will contain, <main python file>, positional-arguments, flags...

    Args:
      flag_values: The flags list to update
      argv: The command line argument list

    Returns:
      The list of position arguments for the given command.

    Raises:
      CommandError: If any problems occur with parsing the commands (e.g.,
          type mistmatches, out of bounds, unknown commands, ...).
    """
    # We use the same positional arguments used by the command's Handle method.
    # For AddDisk this will be, ['self', 'disk_name'].
    argspec = inspect.getargspec(self.Handle)[0]
    var_arg_present = inspect.getargspec(self.Handle)[1]

    # Skip the implicit argument 'self' and take the list of
    # positional command args.
    pos_arg_names = argspec[1:]

    # We then parse off values for those positional arguments from argv.
    # Note that we skip the first argument, as that is the command path.
    pos_arg_values = argv[1:len(pos_arg_names) + 1]

    # If we did not get enough positional argument values print error and exit.
    if len(pos_arg_names) > len(pos_arg_values):
      missing_args = pos_arg_names[len(pos_arg_values):]
      missing_args = ['"%s"' % a for a in missing_args]
      raise CommandError('Positional argument %s is missing.' %
                         ', '.join(missing_args))

    # If users specified flags in place of positional argument values,
    # print error and exit.
    for (name, value) in zip(pos_arg_names, pos_arg_values):
      if value.startswith('--'):
        raise CommandError('Invalid positional argument value \'%s\' '
                           'for argument \'%s\'\n' % (value, name))

    # Take all the arguments other than positional arguments. User might have
    # specified flags there, we will parse them now.
    remaining_flags = [argv[0]] + argv[len(pos_arg_names) + 1:]

    # Parse the flags and store any unparsed arguments.
    try:
      unparsed_args = flag_values(remaining_flags)[1:]
    except (flags.IllegalFlagValue, flags.UnrecognizedFlagError) as e:
      raise CommandError(e)
    except:
      raise CommandError('Unexpected error: %s' % sys.exc_info()[0])

    # If there are any unparsed args and the command is not expecting
    # varargs, print error and exit.
    if unparsed_args and not var_arg_present:
      unparsed_args = ['"%s"' % a for a in unparsed_args]
      raise CommandError('Unknown argument: %s' %
                         ', '.join(unparsed_args))

    pos_arg_values.extend(unparsed_args)

    return pos_arg_values

  def _BuildComputeApi(self, http):
    """Builds the Google Compute Engine API to use.

    Args:
      http: a httplib2.Http like object for communication.

    Returns:
      The API object to use.
    """
    # For versions of the apiclient library prior to v1beta2, we need to
    # specify the LoggingJsonModel in order to get request and response
    # logging to work.
    json_model = (model.LoggingJsonModel()
                  if 'LoggingJsonModel' in dir(model)
                  else model.JsonModel())
    if FLAGS.fetch_discovery:
      discovery_uri = (FLAGS.api_host +
                       'discovery/v1/apis/{api}/{apiVersion}/rest')
      return self.WrapApiIfNeeded(discovery.build(
          'compute',
          FLAGS.service_version,
          http=http,
          discoveryServiceUrl=discovery_uri,
          model=json_model))
    else:
      discovery_file_name = os.path.join(
          os.path.dirname(__file__),
          'compute/%s.json' % FLAGS.service_version)
      try:
        discovery_file = file(discovery_file_name, 'r')
        discovery_doc = discovery_file.read()
        discovery_file.close()
      except IOError:
        raise CommandError(
            'Could not load discovery document from disk. Perhaps try '
            '--fetch_discovery. \nFile: %s' % discovery_file_name)

      return self.WrapApiIfNeeded(discovery.build_from_document(
          discovery_doc,
          FLAGS.api_host,
          http=http,
          model=json_model))

  @staticmethod
  def WrapApiIfNeeded(api):
    if FLAGS.trace_token:
      return TracedComputeApi(api, 'token:%s' % (FLAGS.trace_token))
    return api

  @staticmethod
  def DenormalizeResourceName(project_id, collection_name, resource_name):
    """Return the relative name for the given resource.

    Args:
      project_id: The name of the project containing the resource.
      collection_name: The name of the collection containing the resource.
      resource_name: The name of the resource. This can be either relative
                     or absolute.
    Returns:
      The name of the resource relative to its enclosing collection.

    Raises:
      CommandError: If the name of the resource does not match the given
          project and/or collection.
    """
    resource_name = resource_name.strip('/')
    collection_prefix = 'projects/%s/%s/' % (project_id, collection_name)
    if '/' in resource_name and resource_name.startswith(collection_prefix):
      resource_name = resource_name[len(collection_prefix):]
    if '/' in resource_name:
      raise CommandError('Resource names cannot contain \'/\'')
    return resource_name

  @staticmethod
  def DenormalizeProjectName(flag_values):
    """Denormalize the 'project_id' entry in the given FlagValues instance.

    Args:
      flag_values: The FlagValues instance to update.

    Raises:
      CommandError: If the project_id is missing or malformed.
    """
    if not flag_values.project_id:
      raise CommandError('You must specify a project name'
                         ' using the "--project_id" flag.')
    flag_values.project_id = flag_values.project_id.strip('/')
    if flag_values.project_id.startswith('projects/'):
      flag_values.project_id = flag_values.project_id[len('projects/'):]
    if '/' in flag_values.project_id:
      raise CommandError('Project names must not contain a \'/\'')

  def _GetBaseApiUrl(self):
    """Get the base API URL given the current flag_values.

    Returns:
      The base API URL.  For example,
      https://www.googleapis.com/compute/v1beta11.
    """
    return '%scompute/%s' % (self._flags.api_host, self._flags.service_version)

  def _AddBaseUrlIfNecessary(self, resource_path):
    """Add the base URL to a resource_path if required by the service_version.

    Args:
      resource_path: The resource path to add the URL to.

    Returns:
      A full API-usable reference to the given resource_path.
    """
    if not self._GetBaseApiUrl() in resource_path:
      return '%s/%s' % (self._GetBaseApiUrl(), resource_path)
    return resource_path

  def _StripBaseUrl(self, value):
    """Removes the a base URL from the string if it exists.

    Note that right now the server may not return exactly the right
    base URL so we strip off stuff that looks like a base URL.

    Args:
      value: The string to strip the base URL from.

    Returns:
      A string without the base URL.
    """
    pattern = '^' + re.escape(self._flags.api_host) + r'compute/\w*/'
    return re.sub(pattern, '', value)

  def NormalizeTopLevelResourceName(self, collection_name, resource_name):
    """Return the full name for the given resource.

    Args:
      collection_name: The name of the top-level collection containing the
                       resource.
      resource_name: The name of the resource. This can be either relative
                     to the collection or absolute.

    Returns:
      The full URL of the resource.
    """
    resource_name = resource_name.strip('/')
    if (resource_name.startswith(collection_name + '/') or
        resource_name.startswith(self._flags.api_host)):
      # This does not appear to be a relative name.
      absolute_name = resource_name
    else:
      absolute_name = '%s/%s' % (collection_name, resource_name)

    return self._AddBaseUrlIfNecessary(absolute_name)

  def NormalizeResourceName(self, project_id, collection_name,
                            resource_name):
    """Return the full name for the given resource.

    Args:
      project_id: The name of the project containing the resource.
      collection_name: The name of the collection containing the resource.
      resource_name: The name of the resource. This can be either relative
          or absolute.

    Returns:
      The full URL of the resource.
    """
    resource_name = resource_name.strip('/')
    if (resource_name.startswith('projects/') or
        resource_name.startswith(collection_name + '/') or
        resource_name.startswith(self._flags.api_host)):
      # This does not appear to be a relative name.
      return self._AddBaseUrlIfNecessary(resource_name)

    return self.NormalizeTopLevelResourceName(
        'projects/%s/%s' % (project_id, collection_name),
        resource_name)

  def _DenormalizeResourceName(self, resource_name):
    """Return the relative name for the given resource.

    Relies on the command instance's flags and the presence of a
    resource_collection_name field containing the common collection name
    for the class.

    Args:
      resource_name: The name of the resource. This can be either relative
                     or absolute.

    Returns:
      The name of the resource relative to its enclosing collection.

    Raises:
      CommandError: If the name of the resource does not match the given
          project and/or collection.
    """
    project_id = self._flags.project_id
    collection_name = self.resource_collection_name

    return self.DenormalizeResourceName(project_id, collection_name,
                                        resource_name)

  def _HandleSafetyPrompt(self, positional_arguments):
    """If a safety prompt is present on the class, handle it now.

    By defining a field 'safety_prompt', derived classes can request
    that the user confirm a dangerous operation prior to execution,
    e.g. deleting a resource.  Users may override this check by
    passing the --force flag on the command line.

    Args:
      positional_arguments: A list of positional argument strings.

    Returns:
      True if the command should continue, False if not.
    """
    if hasattr(self, 'safety_prompt'):
      if not self._flags.force:
        prompt = self.safety_prompt
        if positional_arguments:
          prompt = '%s %s' % (prompt, positional_arguments[0])
        print '%s? [y/N]' % prompt
        userinput = raw_input('>>> ')

        if not userinput:
          userinput = 'n'
        userinput = userinput.lstrip()[:1].lower()

        if not userinput == 'y':
          return False

    return True

  def _IsUsingAtLeastApiVersion(self, version):
    """Determine if in-use API version is at least the specified version.

    Args:
      version: The API version to test.

    Returns:
      True if the given API version is equal or newer than the in-use
      API version, False otherwise.

    Raises:
      CommandError: If the specified API version is not known.
    """
    if not (version in self.supported_versions and
            self._flags.service_version in self.supported_versions):
      raise CommandError('API version %s/%s unknown' % (
          version, self._flags.service_version))

    for index, known_version in enumerate(self.supported_versions):
      if known_version == self._flags.service_version:
        current_index = index
      if known_version == version:
        given_index = index

    return current_index >= given_index

  def _GetResourceApiKind(self, resource):
    """Determine the API version driven resource 'kind'.

    Args:
      resource: The resource type to generate a 'kind' string for.

    Returns:
      A string containing the API 'kind'
    """
    return 'compute#%s' % resource

  def Run(self, argv):
    """Run the command, printing the result.

    Args:
      argv: The arguments to the command.

    Returns:
      0 if the command completes successfully, otherwise 1.
    """
    try:
      pos_arg_values = self._ParseArgumentsAndFlags(FLAGS, argv)

      self._SetupLogging()
      # Synchronize the flags with any cached values present.
      flags_cache.FlagsCache().SynchronizeFlags()
      self.SetFlagDefaults()
      self.DenormalizeProjectName(FLAGS)
      self.SetFlags(FLAGS)
      if self._IsUsingAtLeastApiVersion('v1beta12'):
        self.operation_detail_fields = (('name', 'name'),
                                        ('creation time', 'creationTimestamp'),
                                        ('status', 'status'),
                                        ('progress', 'progress'),
                                        ('statusMessage', 'statusMessage'),
                                        ('target', 'targetLink'),
                                        ('target id', 'targetId'),
                                        ('client operation id',
                                         'clientOperationId'),
                                        ('insertTime', 'insertTime'),
                                        ('startTime', 'startTime'),
                                        ('endTime', 'endTime'),
                                        ('operationType', 'operationType'),
                                        ('error code', 'httpErrorStatusCode'),
                                        ('error message', 'httpErrorMessage'))

      try:
        auth_retry = True
        while True:
          try:
            result = self.RunWithFlagsAndPositionalArgs(self._flags,
                                                        pos_arg_values)
            auth_retry = False
          except oauth2_client.AccessTokenRefreshError, e:
            if not auth_retry:
              raise
            # Retrying the operation will induce OAuth2 reauthentication and
            # creation of the new refresh token.
            LOGGER.info('OAuth2 token refresh error (%s), retrying.\n', str(e))
            auth_retry = False
            continue

          self.PrintResult(result)

          if (not self._IsListCommand() or
              not 'nextPageToken' in result or
              not self._flags.fetch_all_pages):
            break
          self._flags.page_token = result['nextPageToken']

        if (self.IsResultAnOperation(result) and
            self._flags.synchronous_mode and
            result.get('error', {}).get('errors', [])):
          return 1
        else:
          return 0
      except errors.HttpError, http_error:
        sys.stderr.write('Error processing request: %s\n' % (
            str(http_error) or str(http_error.content)))
        # Log the full error response for debugging purposes.
        LOGGER.debug(http_error.resp)
        LOGGER.debug(http_error.content)
        return 1

    except app.UsageError:
      raise
    except Exception, e:
      sys.stderr.write('%s\n' % '\n'.join(traceback.format_exception_only(
          sys.exc_type, sys.exc_value)))
      LOGGER.debug(traceback.format_exc())
      return 1

  def RunWithFlagsAndPositionalArgs(self, flag_values, pos_arg_values):
    """Run the command with the parsed flags and positional arguments.

    This method is what a subclass should override if they do not want
    to use the REST API.

    Args:
      flag_values: The parsed FlagValues instance.
      pos_arg_values: The positional arguments for the Handle method.

    Returns:
      The command's result value.
    """
    http = self._AuthenticateWrapper(httplib2.Http())
    compute_api = self._BuildComputeApi(http)
    self._operations_api = compute_api.operations()
    self.SetApi(compute_api)

    if not self._HandleSafetyPrompt(pos_arg_values):
      print 'Operation aborted'
      return {}

    result = self.Handle(*pos_arg_values)
    if self._flags.synchronous_mode:
      result = self.WaitForOperation(flag_values, time, result)

    return result

  def IsResultAnOperation(self, result):
    """Determine if the result object is an operation."""
    try:
      return ('kind' in result
              and result['kind'].endswith('#operation'))
    except TypeError:
      return False

  def WaitForOperation(self, flag_values, timer, result):
    """Wait for a potentially asynchronous operation to complete.

    Args:
      flag_values: The parsed FlagValues instance.
      timer: An implementation of the time object, providing time and sleep
          methods.
      result: The result of the request, potentially containing an operation.

    Returns:
      The synchronous return value, usually a resource object.
    """
    if self.IsResultAnOperation(result):
      start_time = timer.time()
      while (timer.time() - start_time < flag_values.max_wait_time and
             result['status'] not in ['DONE']):
        LOGGER.info(
            'Waiting for asynchronous operation to complete. Current status:'
            ' %s. Sleeping for %ss.',
            result['status'], flag_values.sleep_between_polls)

        timer.sleep(flag_values.sleep_between_polls)

        # Poll the operation for status 'DONE'.
        request = self._operations_api.get(
            project=self._project_id,
            operation=result['name'])
        result = request.execute()

      if result['status'] not in ['DONE']:
        LOGGER.warn('Timeout reached. Operation %s has not yet completed.',
                    result['name'])

    return result

  def CommandGetHelp(self, unused_argv, cmd_names=None):
    """Get help for command.

    Args:
      unused_argv: Remaining command line flags and arguments after parsing
                   command (that is a copy of sys.argv at the time of the
                   function call with all parsed flags removed); unused in this
                   implementation.
      cmd_names:   By default, if help is being shown for more than one command,
                   and this command defines _all_commands_help, then
                   _all_commands_help will be displayed instead of the class
                   doc. cmd_names is used to determine the number of commands
                   being displayed and if only a single command is display then
                   the class doc is returned.

    Returns:
      __doc__ property for command function or a message stating there is no
      help.
    """
    help_str = super(GoogleComputeCommand, self).CommandGetHelp(unused_argv, cmd_names)
    return '%s\n\nUsage: %s' % (help_str, self.__GetUsage())

  def __GetUsage(self):
    """Get the usage string for the command, used to print help messages.

    Returns:
      The usage string for the command.
    """
    argspec = inspect.getargspec(self.Handle)
    pos_arg_names = argspec[0][1:]

    additional_args = self.GetUsageAdditionalArgs()
    if additional_args:
      pos_arg_names.extend(additional_args)

    args = ' '.join(['<%s>' % name for name in pos_arg_names])
    main_name = os.path.basename(sys.argv[0])
    main_name = main_name[:main_name.rfind('.')]
    return '%s [--global_flags] %s %s [--command_flags]' % (
        main_name, self._command_name, args)

  def GetUsageAdditionalArgs(self):
    """Get additional freeform command line arguments.

    Derived classes override this method to indicate
    additional command line options beyond those found in
    the positional arguments.  This is used for commands which
    accept lists of files or free form command line arguments.

    Returns:
      A list of additional arguments.
    """
    pass

  def Handle(self):
    """Actual implementation of the command.

    Derived classes override this method, adding positional arguments
    to this method as required.

    Returns:
      The result of executing the command.
    """
    raise NotImplementedError()

  def SetFlags(self, flag_values):
    """Set the flags to be used by the command.

    Args:
      flag_values: The parsed flags values.
    """
    self._flags = flag_values
    self._project_id = self._flags.project_id

  def GetCommandFlags(self):
    """Retrieve the flags for this command."""
    return self._command_flags

  def SetApi(self, api):
    """Set the Google Compute Engine API for the command.

    Derived classes override this method, pulling the necessary
    domain specific API out of the global API.

    Args:
      api: The Google Compute Engine API used by this command.
    """
    raise NotImplementedError()

  def _PresentElement(self, field_value):
    """Format a json value for tabular display.

    Strips off the project qualifier if present and elides the value
    if it won't fit inside of a max column size of 64 characters.

    Args:
      field_value: The json field value to be formatted.

    Returns:
      The formatted json value.
    """
    if isinstance(field_value, basestring):
      field_value = self._StripBaseUrl(field_value).strip('/')

      if field_value.startswith('projects/' + self._project_id):
        field_value_parts = field_value.split('/')
        if len(field_value_parts) > 3:
          field_value = '/'.join(field_value_parts[3:])
        else:
          field_value = field_value_parts[-1]
      if (self._flags.long_values_display_format == 'elided' and
          len(field_value) > 64):
        return field_value[:31] + '..' + field_value[-31:]
    return field_value

  def _FlattenObjectToList(self, instance_json, name_map):
    """Convert a json instance to a dictionary for output.

    Args:
      instance_json: A JSON object represented as a python dict.
      name_map: A list of key, json-path object tuples where the
          json-path object is either a string or a list of strings.
          ('name', 'container.id') or
          ('name', ['container.id.new', 'container.id.old'])

    Returns:
      A list of extracted values selected by the associated JSON path.  In
      addition, names are simplified to their shortest path components.
    """

    def __ExtractSubKeys(json_object, subkey):
      """Extract and flatten a (possibly-repeated) field in a json object.

      Args:
        json_object: A JSON object represented as a python dict.
        subkey: a list of path elements, e.g. ['container', 'id'].

      Returns:
        [element1, element2, ...] or [] if the subkey could not be found.
      """
      if not subkey:
        return [self._PresentElement(json_object)]
      if subkey[0] in json_object:
        element = json_object[subkey[0]]
        if isinstance(element, list):
          return sum([__ExtractSubKeys(x, subkey[1:]) for x in element], [])
        return __ExtractSubKeys(element, subkey[1:])
      return []

    ret = []
    for unused_key, paths in name_map:
      # There may be multiple possible paths indicating the field name due to
      # versioning changes.  Walk through them in order until one is found.
      if isinstance(paths, basestring):
        elements = __ExtractSubKeys(instance_json, paths.split('.'))
      else:
        for path in paths:
          elements = __ExtractSubKeys(instance_json, path.split('.'))
          if elements:
            break

      ret.append(','.join([str(x) for x in elements]))
    return ret

  def __AddErrorsForOperation(self, result, table):
    """Add any errors present in the operation result to the output table.

    Args:
      result: The json dictionary returned by the server.
      table: The pretty printing table to be customized.
    """
    if 'error' in result:
      table.AddRow(('', ''))
      table.AddRow(('errors', ''))
      for error in result['error']['errors']:
        table.AddRow(('', ''))
        table.AddRow(('  error', error['code']))
        table.AddRow(('  message', error['message']))

  def PrintResult(self, result):
    """Pretty-print the result of the command.

    If a class defines a list of ('title', 'json.field.path') values named
    'fields', this list will be used to print a table of results using
    prettytable.  If self.fields does not exist, result will be printed as
    pretty JSON.

    Args:
      result: The JSON-serializable result to print.
    """
    if self._flags.print_json:
      # We could have used the pprint module, but it produces
      # noisy output due to all of our keys and values being
      # unicode strings rather than simply ascii.
      print json.dumps(result, sort_keys=True, indent=2)
      return

    if not result:
      return

    # Set up the output table.
    table = table_formatter.PrettyFormatter()

    detail_fields = None
    summary_fields = None

    if hasattr(self, 'detail_fields'):
      detail_fields = self.detail_fields

    if hasattr(self, 'summary_fields'):
      summary_fields = self.summary_fields

    if self.IsResultAnOperation(result):
      detail_fields = self.operation_detail_fields

    # Results which return multiple entities will use the 'summary_fields' list.
    detail_view = True
    if self._IsListCommand():
      detail_view = False

    sortby_field = None

    if detail_view:
      row_names = [x[0] for x in detail_fields]
      table.AddColumns(('property', 'value'))
      property_bag = self._FlattenObjectToList(result, detail_fields)
      for i, v in enumerate(property_bag):
        table.AddRow((row_names[i], v))
    else:
      column_names = [x[0] for x in summary_fields]
      table.AddColumns(column_names)

      rows = []
      for row in result.get('items', []):
        rows.append(self._FlattenObjectToList(row, summary_fields))

      # Sorts the rows, if necessary.
      #
      sortby_field = None
      if self._flags.sort_by and self._flags.sort_by in column_names:
        sortby_field = self._flags.sort_by
      elif hasattr(self, 'default_sort_field'):
        sortby_field = self.default_sort_field

      reverse = False
      if sortby_field and sortby_field.startswith('-'):
        reverse = True
        sortby_field = sortby_field[1:]

      if sortby_field:
        sortby_field_idx = column_names.index(sortby_field)
        rows = sorted(rows, key=(lambda row: row[sortby_field_idx]),
                      reverse=reverse)

      table.AddRows(rows)

    if hasattr(self, 'CustomizePrintResult'):
      self.CustomizePrintResult(result, table)

    # Add custom error processing to the output table if we are printing an
    # operation.
    if self.IsResultAnOperation(result):
      self.__AddErrorsForOperation(result, table)

    print table

    if 'nextPageToken' in result:
      if 'fetch_all_pages' in self._flags and not self._flags.fetch_all_pages:
        print 'next page token = ' + result['nextPageToken']

  def __GetRequiredAuthScopes(self):
    """Returns a list of scopes required for this command."""
    return scopes.DEFAULT_AUTH_SCOPES

  def SetFlagDefaults(self):
    if 'project_id' in FLAGS.FlagDict() and not FLAGS['project_id'].present:
      try:
        metadata = metadata_lib.Metadata()
        setattr(FLAGS, 'project_id', metadata.GetProjectId())
      except metadata_lib.MetadataError:
        pass

