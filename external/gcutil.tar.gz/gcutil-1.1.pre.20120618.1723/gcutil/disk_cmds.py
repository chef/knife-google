#!/usr/bin/env python
#
# Copyright 2012 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Commands for interacting with Google Compute Engine persistent disks."""



import time


from google.apputils import appcommands
import gflags as flags

from gcutil import command_base

FLAGS = flags.FLAGS
LOGGER = command_base.LOGGER


class DiskCommand(command_base.GoogleComputeCommand):
  """Base command for working with the disks collection."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'),
                    ('zone', 'zone'),
                    ('size (GB)', 'sizeGb'))

  detail_fields = (('name', 'name'),
                   ('description', 'description'),
                   ('zone', 'zone'),
                   ('size (GB)', 'sizeGb'))

  resource_collection_name = 'disks'

  def __init__(self, name, flag_values):
    super(DiskCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute Engine API for the command.

    Args:
      api: The Google Compute Engine API used by this command.

    Returns:
      None.

    """
    if self._IsUsingAtLeastApiVersion('v1beta12'):
      self.summary_fields = (('name', 'name'),
                             ('description', 'description'),
                             ('zone', 'zone'),
                             ('status', 'status'),
                             ('source snapshot', 'sourceSnapshot'),
                             ('size (GB)', 'sizeGb'))
      self.detail_fields = (('name', 'name'),
                            ('description', 'description'),
                            ('creation time', 'creationTimestamp'),
                            ('zone', 'zone'),
                            ('status', 'status'),
                            ('source snapshot', 'sourceSnapshot'),
                            ('size (GB)', 'sizeGb'))
    self._disks_api = api.disks()
    self._zones_api = api.zones()


class AddDisk(DiskCommand):
  """Create a new machine disk."""

  status_field = 'status'
  _TERMINAL_STATUS = ['READY', 'FAILED']

  def __init__(self, name, flag_values):
    super(AddDisk, self).__init__(name, flag_values)
    flags.DEFINE_string('description',
                        '',
                        'Disk description.',
                        flag_values=flag_values)
    flags.DEFINE_integer('size_gb',
                         10,
                         'The size of the persistent disk in GB.',
                         lower_bound=1,
                         flag_values=flag_values)
    flags.DEFINE_string('zone',
                        None,
                        'The zone for this disk.',
                        flag_values=flag_values)
    flags.DEFINE_string('source_snapshot',
                        None,
                        'The source snapshot for this disk.',
                        flag_values=flag_values)
    flags.DEFINE_boolean('wait_until_complete',
                         False,
                         'Whether the program should wait until the disk'
                         ' is restored from snapshot.',
                         flag_values=flag_values)

  def Handle(self, disk_name):
    """Add the specified disk.

    Args:
      disk_name: The name of the disk to add

    Returns:
      The result of inserting the disk.

    Raises:
      CommandError: If the command is unsupported in this API version.
    """
    self._flags.zone = self._GetZone(self._flags.zone)

    zone = self.NormalizeResourceName(
        self._project_id,
        'zones',
        self._flags.zone)

    disk_resource = {
        'kind': self._GetResourceApiKind('disk'),
        'name': self._DenormalizeResourceName(disk_name),
        'description': self._flags.description,
        'zone': zone,
        'sizeGb': self._flags.size_gb,
        }

    if self._flags.source_snapshot:
      if self._IsUsingAtLeastApiVersion('v1beta12'):
        disk_resource['sourceSnapshot'] = self.NormalizeResourceName(
            self._project_id,
            'snapshots',
            self._flags.source_snapshot)
      else:
        raise command_base.CommandError(
            'Disk snapshots not supported for this API version.')

    disk_request = self._disks_api.insert(project='%s' % self._project_id,
                                          body=disk_resource)

    result = disk_request.execute()

    if self._flags.wait_until_complete:
      result = self.WaitForOperation(self._flags, time, result)
      if not result.get('error'):
        result = self._InternalGetDisk(disk_name)
        result = self._WaitUntilDiskIsComplete(result, disk_name)

    return result

  def _InternalGetDisk(self, disk_name):
    """A simple implementation of getting current disk state.

    Args:
      disk_name: the name of the disk to get.

    Returns:
      Json containing full disk information.
    """
    disk_request = self._disks_api.get(
        project=self._project_id,
        disk=self._DenormalizeResourceName(disk_name))
    return disk_request.execute()

  def _WaitUntilDiskIsComplete(self, result, disk_name):
    """Waits for the disk to complete.

    Periodically polls the server for current disk status. Exits if the
    status of the disk is READY or FAILED or the maximum waiting timeout
    has been reached. In both cases returns the last known disk details.

    Args:
      result: the current state of the disk.
      disk_name: the name of the disk to watch.

    Returns:
      Json containing full disk information.
    """
    current_status = result[self.status_field]
    start_time = time.time()
    LOGGER.info('Will wait for restore for: %d seconds.',
                self._flags.max_wait_time)
    while (time.time() - start_time < self._flags.max_wait_time and
           current_status not in self._TERMINAL_STATUS):
      LOGGER.info(
          'Waiting for disk. Current status: %s. Sleeping for %ss.',
          current_status, self._flags.sleep_between_polls)
      time.sleep(self._flags.sleep_between_polls)
      result = self._InternalGetDisk(disk_name)
      current_status = result[self.status_field]
    if current_status not in self._TERMINAL_STATUS:
      LOGGER.warn('Timeout reached. Disk %s has not yet been restored.',
                  disk_name)
    return result


class GetDisk(DiskCommand):
  """Get a machine disk."""

  def __init__(self, name, flag_values):
    super(GetDisk, self).__init__(name, flag_values)

  def Handle(self, disk_name):
    """Get the specified disk.

    Args:
      disk_name: The name of the disk to get

    Returns:
      The result of getting the disk.
    """
    disk_request = self._disks_api.get(
        project='%s' % self._project_id,
        disk=self._DenormalizeResourceName(disk_name))

    return disk_request.execute()


class DeleteDisk(DiskCommand):
  """Delete a machine disk."""

  safety_prompt = 'Delete disk'

  def __init__(self, name, flag_values):
    super(DeleteDisk, self).__init__(name, flag_values)

  def Handle(self, disk_name):
    """Delete the specified disk.

    Args:
      disk_name: The name of the disk to delete

    Returns:
      The result of deleting the disk.
    """
    disk_request = self._disks_api.delete(
        project='%s' % self._project_id,
        disk=self._DenormalizeResourceName(disk_name))

    return disk_request.execute()


class ListDisks(DiskCommand):
  """List the machine disks for a project."""

  def Handle(self):
    """List the project's disks.

    Args:
      None.

    Returns:
      The result of listing the disks.
    """
    disk_request = self._disks_api.list(**self._BuildListArgs())
    return disk_request.execute()


def AddCommands():
  appcommands.AddCmd('adddisk', AddDisk)
  appcommands.AddCmd('getdisk', GetDisk)
  appcommands.AddCmd('deletedisk', DeleteDisk)
  appcommands.AddCmd('listdisks', ListDisks)
