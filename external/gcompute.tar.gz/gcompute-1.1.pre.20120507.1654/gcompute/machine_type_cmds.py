#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute machine types."""




from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS



class MachineTypeCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the machine types collection."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'),
                    ('cpus', 'guestCpus'),
                    ('memory (MB)', 'memoryMb'),
                    ('ephemeral disk (GB)', 'ephemeralDisks.diskGb'),
                    ('max persistent disks', 'maximumPersistentDisks'),
                    ('max aggregate persistent disks size (GB)',
                     'maximumPersistentDisksSizeGb'))

  detail_fields = (('name', 'name'),
                   ('description', 'description'),
                   ('cpus', 'guestCpus'),
                   ('memory (MB)', 'memoryMb'),
                   ('ephemeral disk (GB)', 'ephemeralDisks.diskGb'),
                   ('max persistent disks', 'maximumPersistentDisks'),
                   ('max aggregate persistent disks size (GB)',
                    'maximumPersistentDisksSizeGb'))

  resource_collection_name = 'machine_types'

  def __init__(self, name, flag_values):
    super(MachineTypeCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._machine_type_api = api.machineTypes()


class GetMachineType(MachineTypeCommand):
  """Get a machine type."""

  def __init__(self, name, flag_values):
    super(GetMachineType, self).__init__(name, flag_values)

  def Handle(self, machine_type_name):
    """Get the specified machine type.

    Args:
      machine_type_name: Name of the machine type to get.

    Returns:
      The result of getting the machine type.
    """
    machine_type_name = self._DenormalizeResourceName(machine_type_name)

    machine_request = self._machine_type_api.get(
        project=self._project_id,
        machineType=machine_type_name)

    return machine_request.execute()


class ListMachineTypes(MachineTypeCommand):
  """List the machine types."""

  def Handle(self):
    """Build a request to list the machine types.

    Args:
      None.

    Returns:
      The result of getting the machine type.
    """
    machine_request = self._machine_type_api.list(**self._BuildListArgs())
    return machine_request.execute()


def AddCommands():
  appcommands.AddCmd('getmachinetype', GetMachineType)
  appcommands.AddCmd('listmachinetypes', ListMachineTypes)
