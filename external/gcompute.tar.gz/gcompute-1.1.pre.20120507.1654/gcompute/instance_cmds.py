#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute VM instances."""




import logging
import os
import time

from apiclient import errors

from google.apputils import app
from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd
from gcompute import metadata
from gcompute import ssh_keys


FLAGS = flags.FLAGS
LOGGER = gcompute_cmd.LOGGER


class InstanceCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the instances collection."""

  default_sort_field = 'name'
  summary_fields = (('name', ['name', 'id']),
                    ('machine', 'machineType'),
                    ('image', 'image'),
                    ('network', 'networkInterfaces.network'),
                    ('network_ip', 'networkInterfaces.networkIP'),
                    ('external_ip', 'networkInterfaces.accessConfigs.natIP'),
                    ('disks', 'disks.source'),
                    ('zone', ['sharedFateZone', 'zone']),
                    ('tags', 'tags'),
                    ('status', 'status'),
                    ('statusMessage', 'statusMessage'))

  # The remaining complex fields are filled in via CustomizePrintResult
  detail_fields = (('name', ['name', 'id']),
                   ('description', 'description'),
                   ('machine', 'machineType'),
                   ('image', 'image'),
                   ('zone', ['sharedFateZone', 'zone']),
                   ('tags', 'tags'),
                   ('status', 'status'),
                   ('statusMessage', 'statusMessage'))

  resource_collection_name = 'instances'

  def __init__(self, name, flag_values):
    super(InstanceCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._projects_api = api.projects()
    self._instances_api = api.instances()
    self._disks_api = api.disks()
    self._machine_types_api = api.machineTypes()
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      self._zones_api = api.zones()
    else:
      self._zones_api = api.sharedFateZones()

  def CustomizePrintResult(self, result, table):
    """Customized result printing for this type.

    Args:
      result: json dictionary returned by the server
      table: the pretty printing table to be customized

    Returns:
      None.

    """
    # Add the disks
    for disk in result.get('disks', []):
      table.add_row(('', ''))
      table.add_row(('disk', disk['index']))
      table.add_row(('  type', disk['type']))
      if 'mode' in disk:
        table.add_row(('  mode', disk['mode']))
      if 'deviceAlias' in disk:
        table.add_row(('  alias', disk['deviceAlias']))
      if 'deviceName' in disk:
        table.add_row(('  name', disk['deviceName']))
      if 'source' in disk:
        table.add_row(('  source', disk['source']))
      if 'deleteOnTerminate' in disk:
        table.add_row(('  delete on terminate', disk['deleteOnTerminate']))

    # Add the networks
    for network in result.get('networkInterfaces', []):
      table.add_row(('', ''))
      table.add_row(('network interface', ''))
      table.add_row(('  network',
                     self._PresentElement(network.get('network', ''))))
      table.add_row(('  ip', network.get('networkIP', '')))
      for config in network.get('accessConfigs', []):
        table.add_row(('  access configuration', config.get('name', '')))
        table.add_row(('    type', config.get('type', '')))
        table.add_row(('    external ip', config.get('natIP', '')))

    # Add the service accounts
    for service_account in result.get('serviceAccounts', []):
      table.add_row(('', ''))
      table.add_row(('service account', service_account.get('email', '')))
      table.add_row(('  scopes', service_account.get('scopes', '')))

    # Add metadata
    if result.get('metadata', []):
      table.add_row(('', ''))
      table.add_row(('metadata', ''))
      metadata_container = result.get('metadata', [])
      if 'kind' in metadata_container:
        metadata_container = metadata_container.get('metadata', [])
      for i in metadata_container:
        table.add_row(('  %s' % i.get('key', ''),
                       self._PresentElement(i.get('value', ''))))

  def _ExtractExternalIpFromInstanceRecord(self, instance_record):
    """Extract the external IP(s) from an instance record.

    Args:
      instance_record: An instance as returned by the Google Compute API.

    Returns:
      A list of internet IP addresses associated with this VM.
    """
    external_ips = set()

    for network_interface in instance_record.get('networkInterfaces', []):
      for access_config in network_interface.get('accessConfigs', []):
        # At the moment, we only know how to translate 1-to-1 NAT
        if (access_config.get('type') == 'ONE_TO_ONE_NAT' and
            'natIP' in access_config):
          external_ips.add(access_config['natIP'])

    return list(external_ips)

  def _AddAuthorizedUserKeyToProject(self, authorized_user_key):
    """Update the project to include the specified user/key pair.

    Args:
      authorized_user_key: A dictionary of a user/key pair for the user.
    Returns:
      True iff the ssh key was added to the project.
    Raises:
      gcompute_cmd.CommandError: If the metadata update fails.
    """
    project = self._projects_api.get(project=self._project_id).execute()
    project_metadata = project.get('commonInstanceMetadata', [])
    if 'kind' in project_metadata:
      project_metadata = project_metadata.get('metadata', [])
    project_ssh_keys = ssh_keys.SshKeys.GetAuthorizedUserKeysFromMetadata(
        project_metadata)
    if authorized_user_key in project_ssh_keys:
      return False
    else:
      project_ssh_keys.append(authorized_user_key)
      ssh_keys.SshKeys.SetAuthorizedUserKeysInMetadata(
          project_metadata, project_ssh_keys)

      metadata_resource_type = 'setMetadata'
      if self._IsUsingAtLeastApiVersion('v1beta11'):
        metadata_resource_type = 'metadata'

      try:
        request = self._projects_api.setCommonInstanceMetadata(
            project=self._project_id,
            body={'kind': self._GetResourceApiKind(metadata_resource_type),
                  'metadata': project_metadata})
        request.execute()
      except errors.HttpError:
        # A failure to add the ssh key probably means that the project metadata
        # has exceeded the max size. The user needs to either manually
        # clean up their project metadata, or set the ssh keys manually for this
        # instance. Either way, trigger a usage error to let them know.
        raise gcompute_cmd.CommandError(
            'Unable to add the local ssh key to the project. Either manually '
            'remove some entries from the commonInstanceMetadata field of the '
            'project, or explicitly set the authorized keys for this instance.')
      return True

  def _AddComputeKeyToProject(self):
    """Update the current project to include the user's public ssh key.

    Returns:
      True iff the ssh key was added to the project.
    """
    compute_key = ssh_keys.SshKeys.GetPublicKey()
    return self._AddAuthorizedUserKeyToProject(compute_key)


class AddInstance(InstanceCommand):
  """Create a new machine instance."""

  status_field = 'status'
  _TERMINAL_STATUS = ['RUNNING', 'TERMINATED']
  # Wait for startup at most 15 minutes.
  _MAX_WAITING_TIME = 60 * 15

  def __init__(self, name, flag_values):
    super(AddInstance, self).__init__(name, flag_values)

    flags.DEFINE_string('description',
                        '',
                        'Instance description',
                        flag_values=flag_values)
    flags.DEFINE_string('image',
                        None,
                        'Image name',
                        flag_values=flag_values)
    flags.DEFINE_string('machine_type',
                        None,
                        'Machine type name',
                        flag_values=flag_values)
    flags.DEFINE_string('network',
                        'default',
                        'The network to which to attach the instance.',
                        flag_values=flag_values)
    flags.DEFINE_string('internal_ip_address',
                        '',
                        'The internal (within the specified network) IP '
                        'address for the instance; if not set the instance '
                        'will be assigned an appropriate address.',
                        flag_values=flag_values)
    flags.DEFINE_string('external_ip_address',
                        'ephemeral',
                        'The external NAT IP address for the instance; Options '
                        'are "ephemeral", "none" or an explicit IP. Setting '
                        'this to an empty string is equivalent to "none". The '
                        'default is "ephemeral".',
                        flag_values=flag_values)
    flags.DEFINE_multistring('disk',
                             [],
                             'The name of a disk that should be attached to '
                             'the instance. Optionally, can supply device '
                             'name in the form disk:deviceName.',
                             flag_values=flag_values)
    flags.DEFINE_boolean('use_compute_key',
                         False,
                         'Whether or not to include the default Google Compute '
                         'ssh key as one of the authorized ssh keys for the '
                         'created instance. This has the side effect of '
                         'disabling project-wide ssh key management for the '
                         'instance.',
                         flag_values=flag_values)
    flags.DEFINE_boolean('add_compute_key_to_project',
                         None,
                         'Whether or not to add the default Google Compute '
                         'ssh key as one of the authorized ssh keys for the '
                         'project. If the default key has already been added '
                         'to the project, then this will have no effect. The '
                         'default behavior is to add the key to the project if '
                         'no instance-specific keys are defined.',
                         flag_values=flag_values)
    flags.DEFINE_list('authorized_ssh_keys',
                      [],
                      'Fix the list of user/key-file pairs to the specified '
                      'entries, disabling project-wide key management for this '
                      'instance. These are specified as a comma separated list '
                      'of colon separated entries: '
                      'user1:keyfile1,user2:keyfile2,...',
                      flag_values=flag_values)
    flags.DEFINE_string('zone',
                        None,
                        'The zone for this instance.',
                        flag_values=flag_values)
    flags.DEFINE_string('service_account',
                        'default',
                        'The service account whose credentials are to be made'
                        ' available for this instance.',
                        flag_values=flag_values)
    flags.DEFINE_list('service_account_scopes',
                      [],
                      'The scopes of credentials of the above service'
                      ' account that are to be made available for this'
                      ' instance (comma separated).',
                      flag_values=flag_values)
    flags.DEFINE_boolean('wait_until_running',
                         False,
                         'Whether the program should wait until the instance is'
                         ' in running state.',
                         flag_values=flag_values)
    flags.DEFINE_list('tags',
                      [],
                      'A set of tags applied to this instance. Used for '
                      'filtering and to configure network firewall rules '
                      '(comma separated).',
                      flag_values=flag_values)

    self._metadata_flags_processor = metadata.MetadataFlagsProcessor(
        flag_values)

  def Handle(self, instance_name):
    """Add the specified instance.

    Args:
      instance_name: The name of the instance to add.

    Returns:
      The result of adding the instance.
    """
    if not self._flags.zone:
      self._flags.zone = (
          self._FindDefaultZone(self._flags.disk) or
          self._PromptForZone())
    if not self._flags.machine_type:
      self._flags.machine_type = self._PromptForMachineType()

    instance_metadata = self._metadata_flags_processor.GatherMetadata()
    if self._flags.authorized_ssh_keys or self._flags.use_compute_key:
      instance_metadata = self._AddSshKeysToMetadata(instance_metadata)

    if self._flags.add_compute_key_to_project or (
        self._flags.add_compute_key_to_project is None and
        not 'sshKeys' in [entry.get('key', '') for entry in instance_metadata]):
      self._AddComputeKeyToProject()

    instance_request = self._BuildRequestWithMetadata(
        instance_name, instance_metadata)
    result = instance_request.execute()

    if self._flags.wait_until_running:
      result = self.WaitForOperation(self._flags, time, result)

      get_request = self._instances_api.get(
          project=self._project_id,
          instance=self._DenormalizeResourceName(instance_name))

      result = get_request.execute()
      result = self._WaitUntilInstanceIsRunning(result, instance_name)

    return result

  def _InternalGetInstance(self, instance_name):
    """A simple implementation of getting current instance state.

    Args:
      instance_name: the name of the instance to get.

    Returns:
      Json containing full instance information.
    """
    instance_request = self._instances_api.get(
        project=self._project_id,
        instance=self._DenormalizeResourceName(instance_name))
    return instance_request.execute()

  def _WaitUntilInstanceIsRunning(self, result, instance_name):
    """Waits for the instance to start.

    Periodically polls the server for current instance status. Exits if the
    status of the instance is RUNNING or TERMINATED or the maximum waiting
    timeout has been reached. In both cases returns the last known instance
    details.

    Args:
      result: the current state of the instance.
      instance_name: the name of the instance to watch.

    Returns:
      Json containing full instance information.
    """
    current_status = result[self.status_field]
    start_time = time.time()
    LOGGER.info('Will wait to start for: %d seconds.',
                self._flags.max_wait_time)
    while (time.time() - start_time < self._flags.max_wait_time and
           current_status not in self._TERMINAL_STATUS):
      LOGGER.info(
          'Waiting for instance start. Current status: %s. Sleeping for %ss.',
          current_status, self._flags.sleep_between_polls)
      time.sleep(self._flags.sleep_between_polls)
      result = self._InternalGetInstance(instance_name)
      current_status = result[self.status_field]
    if current_status not in self._TERMINAL_STATUS:
      LOGGER.warn('Timeout reached. Instance %s has not yet started.',
                  instance_name)
    return result

  def _FindDefaultZone(self, disks):
    """Given the persistent disks for an instance, find a default zone.

    Args:
      disks: The list of persistent disks to be used by the instance.

    Returns:
      The name of a zone if a clear default can be determined
      from the persistent disks, otherwise None.
    """
    for disk in disks:
      # Remove the device name component of the name, if it exists
      if ':' in disk:
        disk = disk.split(':')[0]
      disk_name = self.DenormalizeResourceName(
          self._project_id, 'disks', disk)
      get_request = self._disks_api.get(
          project=self._project_id, disk=disk_name)
      if self._IsUsingAtLeastApiVersion('v1beta11'):
        return get_request.execute()['zone']
      else:
        return get_request.execute()['sharedFateZone']

  def _AddSshKeysToMetadata(self, instance_metadata):
    instance_ssh_keys = ssh_keys.SshKeys.GetAuthorizedUserKeys(
        use_compute_key=self._flags.use_compute_key,
        authorized_ssh_keys=self._flags.authorized_ssh_keys)
    if instance_ssh_keys:
      new_value = ['%(user)s:%(key)s' % user_key
                   for user_key in instance_ssh_keys]
      # Have the new value extend the old value
      old_values = [entry['value'] for entry in instance_metadata
                    if entry['key'] == 'sshKeys']
      all_values = '\n'.join(old_values + new_value)
      instance_metadata = [entry for entry in instance_metadata
                           if entry['key'] != 'sshKeys']
      instance_metadata.append({'key': 'sshKeys', 'value': all_values})
    return instance_metadata

  def _BuildRequestWithMetadata(self, instance_name, instance_metadata):
    """Build a request to add the specified instance, given the ssh keys for it.

    Args:
      instance_name: Name of the instance to build a request for.
      instance_metadata: The metadata to be passed to the VM.  This is in the
        form of [{'key': <key>, 'value': <value>}] form, ready to be
        sent to the server.

    Returns:
      The prepared instance request.

    Raises:
      app.UsageError: If service account explicitly given without scopes.
      gcompute_cmd.CommandError: If scopes contains ' '.
    """
    instance_resource = {
        'kind': self._GetResourceApiKind('instance'),
        'name': self._DenormalizeResourceName(instance_name),
        'description': self._flags.description,
        'networkInterfaces': [],
        'disks': [],
        'metadata': [],
        }

    (zone_field_name, zone_collection_name) = self._GetZoneFieldNames()

    if self._flags.image:
      instance_resource['image'] = self.NormalizeResourceName(self._project_id,
                                                              'images',
                                                              self._flags.image)

    if self._flags.machine_type:
      instance_resource['machineType'] = self.NormalizeResourceName(
          self._project_id,
          'machine-types',
          self._flags.machine_type)

    instance_resource[zone_field_name] = self.NormalizeResourceName(
        self._project_id,
        zone_collection_name,
        self._flags.zone)

    if self._flags.network:
      network_interface = {
          'network': self.NormalizeResourceName(
              self._project_id, 'networks', self._flags.network)
          }
      if self._flags.internal_ip_address:
        network_interface['networkIP'] = self._flags.internal_ip_address
      external_ip_address = self._flags.external_ip_address
      if external_ip_address and external_ip_address.lower() != 'none':
        access_config = {
            'name': 'External NAT',
            'type': 'ONE_TO_ONE_NAT',
            }
        if external_ip_address.lower() != 'ephemeral':
          access_config['natIP'] = self._flags.external_ip_address

        network_interface['accessConfigs'] = [access_config]

      instance_resource['networkInterfaces'].append(network_interface)

    device_name_key = 'deviceAlias'
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      device_name_key = 'deviceName'
    for disk in self._flags.disk:
      new_disk = {}
      disk_info = disk.split(':')
      if len(disk_info) > 1:
        new_disk[device_name_key] = disk_info[1]
        # Remove the deviceName portion from the diskName
        disk = disk_info[0]
      else:
        # No deviceName was specified -- fill with the name of the disk
        new_disk[device_name_key] = disk

      new_disk['type'] = 'PERSISTENT'
      new_disk['source'] = self.NormalizeResourceName(
          self._project_id, 'disks', disk)
      instance_resource['disks'].append(new_disk)

    if self._IsUsingAtLeastApiVersion('v1beta11'):
      metadata_subresource = {
          'kind': self._GetResourceApiKind('metadata'),
          'metadata': [],
          }

      metadata_subresource['metadata'].extend(instance_metadata)
      instance_resource['metadata'] = metadata_subresource
    else:
      instance_resource['metadata'].extend(instance_metadata)

    if self._flags.service_account and (
        len(self._flags.service_account_scopes)):

      # Ensures that the user did not space-delimit his or her scopes
      # list.
      for scope in self._flags.service_account_scopes:
        if ' ' in scope:
          raise gcompute_cmd.CommandError(
              'Scopes list must be comma-delimited, not space-delimited.')

      instance_resource['serviceAccounts'] = []
      instance_resource['serviceAccounts'].append({
          'email': self._flags.service_account,
          'scopes': sorted(self._flags.service_account_scopes)})
    elif self._flags['service_account'].present:
      raise app.UsageError(
          '--service_account given without --service_account_scopes.')

    instance_resource['tags'] = self._flags.tags

    return self._instances_api.insert(project=self._project_id,
                                      body=instance_resource)


class GetInstance(InstanceCommand):
  """Get a machine instance."""

  def __init__(self, name, flag_values):
    super(GetInstance, self).__init__(name, flag_values)

  def Handle(self, instance_name):
    """Get the specified instance.

    Args:
      instance_name: The name of the instance to get.

    Returns:
      The result of getting the instance.
    """
    instance_request = self._instances_api.get(
        project=self._project_id,
        instance=self._DenormalizeResourceName(instance_name))

    return instance_request.execute()


class DeleteInstance(InstanceCommand):
  """Delete a machine instance."""

  safety_prompt = 'Delete instance'

  def __init__(self, name, flag_values):
    super(DeleteInstance, self).__init__(name, flag_values)

  def Handle(self, instance_name):
    """Delete the specified instance.

    Args:
      instance_name: The name of the instance to get.

    Returns:
      The result of deleting the instance.
    """
    instance_request = self._instances_api.delete(
        project=self._project_id,
        instance=self._DenormalizeResourceName(instance_name))

    return instance_request.execute()


class ListInstances(InstanceCommand):
  """List the machine instances for a project."""

  def Handle(self):
    """Build a request to list the project's instances.

    Args:
      None.

    Returns:
      The result of listing the instances.
    """
    instance_request = self._instances_api.list(**self._BuildListArgs())
    return instance_request.execute()

  def CustomizePrintResult(self, result, table):
    """Customized result printing for this type.

    Args:
      result: json dictionary returned by the server
      table: the pretty printing table to be customized

    Returns:
      None.

    """
    pass


class SshInstanceBase(InstanceCommand):
  """Base class for SSH-based commands."""

  def __init__(self, name, flag_values):
    super(SshInstanceBase, self).__init__(name, flag_values)

    flags.DEFINE_integer(
        'ssh_port',
        22,
        'TCP port to connect to',
        flag_values=flag_values)
    flags.DEFINE_multistring(
        'ssh_arg',
        [],
        'Additional arguments to pass to ssh',
        flag_values=flag_values)
    flags.DEFINE_integer(
        'ssh_key_push_wait_time',
        60,
        'Number of seconds to wait for updates to project-wide ssh keys '
        'to cascade to the instances within the project',
        flag_values=flag_values)

  def PrintResult(self, _):
    """Override the PrintResult to be a noop."""
    pass

  def _GetInstanceResource(self, instance_name):
    """Get the instance resource. This is the dictionary returned by the API.

    Args:
      instance_name: The name of the instance to retrieve the ssh address for.

    Returns:
      The data for the instance resource as returned by the API.

    Raises:
      gcompute_cmd.CommandError: If the instance does not exist.
    """
    instance_name = self._DenormalizeResourceName(instance_name)
    request = self._instances_api.get(
        project=self._project_id, instance=instance_name)
    result = request.execute()
    if not result:
      raise gcompute_cmd.CommandError(
          'Unable to find the instance %s.' % (instance_name))
    return result

  def _GetSshAddress(self, instance_resource):
    """Retrieve the ssh address from the passed instance resource data.

    Args:
      instance_resource: The resource data of the instance for which
        to retrieve the ssh address.

    Returns:
      The ssh address and port.

    Raises:
      gcompute_cmd.CommandError: If the instance has no external address.
    """
    external_addresses = self._ExtractExternalIpFromInstanceRecord(
        instance_resource)
    if len(external_addresses) < 1:
      raise gcompute_cmd.CommandError(
          'Cannot connect to an instance with no external address')

    return (external_addresses[0], self._flags.ssh_port)

  def _EnsureSshable(self, instance_resource):
    """Ensure that the user can ssh into the specified instance.

    This method checks if the instance has SSH keys defined for it, and if
    it does not this makes sure the enclosing project contains a metadata
    entry for the user's public ssh key.

    If the project is updated to add the user's ssh key, then this method
    waits for the amount of time specified by the wait_time_for_ssh_key_push
    flag for the change to cascade down to the instance.

    Args:
      instance_resource: The resource data for the instance to which to connect.
    Raises:
      gcompute_cmd.CommandError: If the instance is not in the RUNNING state.
    """
    instance_status = instance_resource.get('status')
    if instance_status != 'RUNNING':
      raise gcompute_cmd.CommandError(
          'Cannot connect to the instance since its current status is %s.'
          % instance_status)

    instance_metadata = instance_resource.get('metadata', [])
    if 'kind' in instance_metadata:
      instance_metadata = instance_metadata.get('metadata', [])
    instance_ssh_key_entries = (
        [entry for entry in instance_metadata if entry.get('key') == 'sshKeys'])

    if instance_ssh_key_entries:
      pass
    elif self._AddComputeKeyToProject():
      wait_time = self._flags.ssh_key_push_wait_time
      LOGGER.info('Waiting %s seconds for the instance to pick up the '
                  'newly-added ssh key.', wait_time)
      time.sleep(wait_time)

  def _BuildSshCmd(self, instance_resource, command, args):
    """Builds the given SSH-based command line with the given arguments.

    A complete SSH-based command line is built from the given command,
    any common arguments, and the arguments provided. The value of
    each argument is formatted using a dictionary that contains the
    following keys: host and port.

    Args:
      instance_resource: The resource data of the instance for which
        to build the ssh command.
      command: the ssh-based command to run (e.g. ssh or scp)
      args: arguments for the command

    Returns:
      The command line used to perform the requested ssh operation.

    Raises:
      IOError: An error occured accessing SSH details.
    """
    (host, port) = self._GetSshAddress(instance_resource)
    values = {'host': host,
              'port': port,
              'user': self._flags.ssh_user}

    command_line = [
        command,
        '-o', 'UserKnownHostsFile=/dev/null',
        '-o', 'CheckHostIP=no',
        '-o', 'StrictHostKeyChecking=no',
        '-i', self._flags.private_key_file
    ] + self._flags.ssh_arg

    if LOGGER.level <= logging.DEBUG:
      command_line.append('-v')
    else:
      command_line.extend(['-o', 'LogLevel=QUIET'])

    for arg in args:
      command_line.append(arg % values)

    return command_line

  def _RunSshCmd(self, instance_name, command, args):
    """Run the given SSH-based command line with the given arguments.

    The specified SSH-base command is run for the arguments provided.
    The value of each argument is formatted using a dictionary that
    contains the following keys: host and port.

    Args:
      instance_name: The name of the instance for which to run the ssh command.
      command: the ssh-based command to run (e.g. ssh or scp)
      args: arguments for the command

    Raises:
      IOError: An error occured accessing SSH details.
    """
    instance_resource = self._GetInstanceResource(instance_name)
    command_line = self._BuildSshCmd(instance_resource, command, args)
    self._EnsureSshable(instance_resource)

    LOGGER.info('Running command line: %s', ' '.join(command_line))
    os.execvp(command, command_line)


class SshToInstance(SshInstanceBase):
  """Ssh to an instance."""

  def _GenerateSshArgs(self, *argv):
    """Generates the command line arguments for the ssh command.

    Args:
      argv: List of additional ssh command line args, if any.

    Returns:
      The complete ssh argument list.
    """
    ssh_args = ['-A', '-p', '%(port)d', '%(user)s@%(host)s', '--']

    escaped_args = [a.replace('%', '%%') for a in argv]
    ssh_args.extend(escaped_args)

    return ssh_args

  def Handle(self, instance_name, *argv):
    """SSH into the instance.

    Args:
      instance_name: The name of the instance to ssh to.
      argv: The remaining unhandled arguments.

    Returns:
      The result of the ssh command
    """
    ssh_args = self._GenerateSshArgs(*argv)
    self._RunSshCmd(instance_name, 'ssh', ssh_args)

  def GetUsageAdditionalArgs(self):
    """Get additional freeform command line arguments.

    Args:
      None.

    Returns:
      A list of additional arguments.
    """
    return ['ssh_arguments']


class PushToInstance(SshInstanceBase):
  """Push one or more files to an instance."""

  def _GenerateScpArgs(self, *argv):
    """Generates the command line arguments for the scp command.

    Args:
      argv: List of files to push and instance-relative destination.

    Returns:
      The scp argument list.

    Raises:
      gcompute_cmd.CommandError: If an invalid number of arguments are passed
          in.
    """
    if len(argv) < 2:
      raise gcompute_cmd.CommandError(
          'Invalid number of arguments passed: %i' % (len(argv) - 1))

    scp_args = ['-P', '%(port)d', '--']

    escaped_args = [a.replace('%', '%%') for a in argv]
    scp_args.extend(escaped_args[0:-1])
    scp_args.append('%(user)s@%(host)s:' + escaped_args[-1])

    return scp_args

  def Handle(self, instance_name, *argv):
    """Pushes one or more files into the instance.

    Args:
      instance_name: The name of the instance to push files to.
      argv: The remaining unhandled arguments.

    Returns:
      The result of the scp command

    Raises:
      gcompute_cmd.CommandError: If an invalid number of arguments are passed
        in.
    """
    scp_args = self._GenerateScpArgs(*argv)
    self._RunSshCmd(instance_name, 'scp', scp_args)

  def GetUsageAdditionalArgs(self):
    """Get additional freeform command line arguments.

    Args:
      None.

    Returns:
      A list of additional arguments.
    """
    return ['file1', 'file2', '...', 'destdir']


class PullFromInstance(SshInstanceBase):
  """Pull one or more files from an instance."""

  def _GenerateScpArgs(self, *argv):
    """Generates the command line arguments for the scp command.

    Args:
      argv: List of files to pull and local-relative destination.

    Returns:
      The scp argument list.

    Raises:
      gcompute_cmd.CommandError: If an invalid number of arguments are passed
          in.
    """
    if len(argv) < 2:
      raise gcompute_cmd.CommandError(
          'Invalid number of arguments passed: %i' % (len(argv) - 1))

    scp_args = ['-P', '%(port)d', '--']

    escaped_args = [a.replace('%', '%%') for a in argv]
    for arg in escaped_args[0:-1]:
      scp_args.append('%(user)s@%(host)s:' + arg)
    scp_args.append(escaped_args[-1])

    return scp_args

  def Handle(self, instance_name, *argv):
    """Pulls one or more files from the instance.

    Args:
      instance_name: The name of the instance to pull files from.
      argv: The remaining unhandled arguments.

    Returns:
      The result of the scp command

    Raises:
      gcompute_cmd.CommandError: If an invalid number of arguments are passed
          in.
    """
    scp_args = self._GenerateScpArgs(*argv)
    self._RunSshCmd(instance_name, 'scp', scp_args)

  def GetUsageAdditionalArgs(self):
    """Get additional freeform command line arguments.

    Args:
      None.

    Returns:
      A list of additional arguments.
    """
    return ['file1', 'file2', '...', 'destdir']


def AddCommands():
  appcommands.AddCmd('addinstance', AddInstance)
  appcommands.AddCmd('getinstance', GetInstance)
  appcommands.AddCmd('deleteinstance', DeleteInstance)
  appcommands.AddCmd('listinstances', ListInstances)
  appcommands.AddCmd('ssh', SshToInstance)
  appcommands.AddCmd('push', PushToInstance)
  appcommands.AddCmd('pull', PullFromInstance)
