#!/usr/bin/env python
#
# Copyright 2011 Google Inc. All Rights Reserved.
#

"""Unit tests for the asynchronous operations commands."""



import copy

import gflags as flags
import unittest

from gcompute import mock_compute_api
from gcompute import operation_cmds

FLAGS = flags.FLAGS


class OperationCmdsTest(unittest.TestCase):

  def testGetOperationGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = operation_cmds.GetOperation('getoperation', flag_values)

    expected_project = 'test_project'
    expected_operation = 'test_operation'
    service_version = 'v1beta10'
    flag_values.project_id = expected_project
    flag_values.service_version = service_version

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_operation)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['operation'], expected_operation)

  def testDeleteOperationGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = operation_cmds.DeleteOperation('deleteimage', flag_values)

    expected_project = 'test_project'
    expected_operation = 'test_operation'
    service_version = 'v1beta10'
    flag_values.project_id = expected_project
    flag_values.service_version = service_version

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_operation)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['operation'], expected_operation)

  def testListOperationsGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = operation_cmds.ListOperations('listoperations', flag_values)

    expected_project = 'test_project'
    service_version = 'v1beta10'
    flag_values.project_id = expected_project
    flag_values.service_version = service_version

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)

if __name__ == '__main__':
  unittest.main()
