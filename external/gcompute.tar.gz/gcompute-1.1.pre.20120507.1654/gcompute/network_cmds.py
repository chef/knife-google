#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute VM networks."""





from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS


class NetworkCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the networks collection."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'),
                    ('addresses', 'IPv4Range'),
                    ('gateway', 'gatewayIPv4'))

  detail_fields = (('name', 'name'),
                   ('description', 'description'),
                   ('addresses', 'IPv4Range'),
                   ('gateway', 'gatewayIPv4'))

  resource_collection_name = 'networks'

  def __init__(self, name, flag_values):
    super(NetworkCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._networks_api = api.networks()


class AddNetwork(NetworkCommand):
  """Create a new network instance."""

  def __init__(self, name, flag_values):
    super(NetworkCommand, self).__init__(name, flag_values)

    flags.DEFINE_string('description',
                        '',
                        'Network description.',
                        flag_values=flag_values)
    flags.DEFINE_string('range',
                        '10.0.0.0/8',
                        'IPv4 address range of this network.',
                        flag_values=flag_values)
    flags.DEFINE_string('gateway',
                        '10.0.0.1',
                        'IPv4 address of the gateway within the network.',
                        flag_values=flag_values)
    flags.DEFINE_list('reserve',
                      [],
                      'IPv4 addresses on the network which should not be '
                      'automatically assigned (comma separated).',
                      flag_values=flag_values)

  def Handle(self, network_name):
    """Add the specified network.

    Args:
      network_name: The name of the network to add.

    Returns:
      The result of adding the network.
    """
    network_resource = {
        'kind': self._GetResourceApiKind('network'),
        'name': self._DenormalizeResourceName(network_name),
        'description': self._flags.description,
        'IPv4Range': self._flags.range,
        'gatewayIPv4': self._flags.gateway,
        'reservedIPv4': self._flags.reserve,
        }

    network_request = self._networks_api.insert(project=self._project_id,
                                                body=network_resource)
    return network_request.execute()


class GetNetwork(NetworkCommand):
  """Get a network instance."""

  def __init__(self, name, flag_values):
    super(GetNetwork, self).__init__(name, flag_values)

  def Handle(self, network_name):
    """Get the specified network.

    Args:
      network_name: The name of the network to get.

    Returns:
      The result of getting the network.
    """
    network_request = self._networks_api.get(
        project=self._project_id,
        network=self._DenormalizeResourceName(network_name))

    return network_request.execute()


class DeleteNetwork(NetworkCommand):
  """Delete a machine network."""

  safety_prompt = 'Delete network'

  def __init__(self, name, flag_values):
    super(DeleteNetwork, self).__init__(name, flag_values)

  def Handle(self, network_name):
    """Delete the specified network.

    Args:
      network_name: The name of the network to get.

    Returns:
      The result of deleting the network.
    """
    network_request = self._networks_api.delete(
        project=self._project_id,
        network=self._DenormalizeResourceName(network_name))

    return network_request.execute()


class ListNetworks(NetworkCommand):
  """List the machine networks for a project."""

  def Handle(self):
    """List the project's networks.

    Args:
      None.

    Returns:
      The result of listing the networks.
    """
    network_request = self._networks_api.list(**self._BuildListArgs())
    return network_request.execute()


def AddCommands():
  appcommands.AddCmd('addnetwork', AddNetwork)
  appcommands.AddCmd('getnetwork', GetNetwork)
  appcommands.AddCmd('deletenetwork', DeleteNetwork)
  appcommands.AddCmd('listnetworks', ListNetworks)
