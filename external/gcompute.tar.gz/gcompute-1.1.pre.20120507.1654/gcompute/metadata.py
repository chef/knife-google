#!/usr/bin/env python
#
# Copyright 2011 Google Inc. All Rights Reserved.
#

"""Helper class for metadata parsing from flags and reading from files."""

from __future__ import with_statement




from google.apputils import app
import gflags as flags


class MetadataFlagsProcessor(object):
  """Helper class for processing flags and building the metadata list."""

  def __init__(self, flag_values):
    flags.DEFINE_multistring('metadata',
                             [],
                             'Metadata to be made available within the VM '
                             'environment via the local metadata server. This '
                             'should be in the form key:value',
                             flag_values=flag_values)
    flags.DEFINE_multistring('metadata_from_file',
                             [],
                             'Metadata to be made available within the VM '
                             'environment via the local metadata server. The '
                             'value is loaded from a file. This should be in '
                             'the form key:filename.',
                             flag_values=flag_values)
    self._flags = flag_values

  def GatherMetadata(self):
    """Gather the list of metadata dictionaries based on the parsed flag values.

    Returns:
      A list of 'key'/'value' dictionaries defining the metadata.
    Raises:
      app.UsageError: If the parsed flag values are malformed.
    """
    metadata_dict = {}

    def GatherFromList(metadata_entries, metadata_dict):
      for metadata in metadata_entries:
        if ':' not in metadata:
          raise app.UsageError('Wrong syntax for metadata %s.  Use key:value.',
                               metadata)
        key_value = metadata.split(':', 1)
        key = key_value[0]
        value = ''
        if len(key_value) > 1:
          value = key_value[1]
          metadata_dict[key] = value

    def GatherFromFiles(metadata_files, metadata_dict):
      for metadata_entry in metadata_files:
        if ':' not in metadata_entry:
          raise app.UsageError('Wrong syntax for metadata_from_file %s.  '
                               'Use key:filename.', metadata_entry)
        key_value = metadata_entry.split(':', 1)
        key = key_value[0]
        if len(key_value) != 2:
          raise app.UsageError('No metadata file specified for %s.', key)
        with open(key_value[1], 'r') as f:
          metadata_dict[key] = f.read()

    GatherFromList(self._flags.metadata, metadata_dict)
    GatherFromFiles(self._flags.metadata_from_file, metadata_dict)

    result = []
    # We sort here to make testing easier.
    result.extend([{'key': k, 'value': v}
                   for (k, v) in sorted(metadata_dict.items())])
    return result
