#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the persistent disk commands."""



import copy
import sys

import gflags as flags
import unittest

from gcompute import disk_cmds
from gcompute import gcompute_cmd
from gcompute import mock_compute_api


FLAGS = flags.FLAGS


def IsOldZoneSyntaxVersion(service_version):
  """Returns if the service version uses the old a/b/c style SFZ syntax.

  Args:
    service_version: The version of the API.

  Returns:
    True if the version is old, False otherwise.
  """
  if 'v1beta10' in service_version:
    return True
  return False


def GetZoneData(service_version):
  """Returns the name of zone-relevant fields based on API version.

  Args:
    service_version: The version of the API.

  Returns:
    A tuple of the resource's zone field name and the name of the REST
    collection.
  """
  if IsOldZoneSyntaxVersion(service_version):
    zone_field_name = 'sharedFateZone'
    zone_collection_name = 'shared-fate-zones'
  else:
    zone_field_name = 'zone'
    zone_collection_name = 'zones'

  return (zone_field_name, zone_collection_name)


class DiskCmdsTest(unittest.TestCase):

  def _doTestAddDiskGeneratesCorrectRequest(self, service_version):
    flag_values = copy.deepcopy(FLAGS)

    command = disk_cmds.AddDisk('adddisk', flag_values)

    expected_project = 'test_project'
    expected_disk = 'test_disk'
    expected_description = 'test disk'
    if IsOldZoneSyntaxVersion(service_version):
      submitted_zone = 'copernicus/moon/base'
    else:
      submitted_zone = 'copernicus-moon-base'
    expected_size = 20
    flag_values.service_version = service_version
    flag_values.zone = submitted_zone
    flag_values.project_id = expected_project
    flag_values.size_gb = expected_size
    flag_values.description = expected_description

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_disk)

    (zone_field_name, zone_collection_name) = GetZoneData(service_version)

    expected_zone = command.NormalizeResourceName(
        expected_project,
        zone_collection_name,
        submitted_zone)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['body']['name'], expected_disk)
    self.assertEqual(result['body']['description'], expected_description)
    self.assertEqual(result['body']['sizeGb'], expected_size)
    self.assertEqual(result['body'][zone_field_name], expected_zone)

  def testAddDiskGeneratesCorrectRequest(self):
    for version in gcompute_cmd.SUPPORTED_VERSIONS:
      self._doTestAddDiskGeneratesCorrectRequest(version)

  def testAddDiskRequiresSharedFateZone(self):
    flag_values = copy.deepcopy(FLAGS)

    command = disk_cmds.AddDisk('adddisk', flag_values)

    expected_project = 'test_project'
    expected_disk = 'test_disk'
    expected_description = 'test disk'
    expected_size = 20
    submitted_version = gcompute_cmd.CURRENT_VERSION
    if IsOldZoneSyntaxVersion(submitted_version):
      submitted_zone = 'us/east/a'
    else:
      submitted_zone = 'us-east-a'

    flag_values.service_version = submitted_version
    flag_values.project_id = expected_project
    flag_values.size_gb = expected_size
    flag_values.description = expected_description

    command.SetFlags(flag_values)

    (zone_field_name, zone_collection_name) = GetZoneData(submitted_version)

    def GetZonePath(part_one, part_two, part_three):
      if IsOldZoneSyntaxVersion(submitted_version):
        separator = '/'
      else:
        separator = '-'

      zone_path = 'projects/test_project/%s/%s%s%s%s%s' % (
          zone_collection_name, part_one, separator, part_two, separator,
          part_three)

      return zone_path

    zones = {
        'items': [
            {'name': GetZonePath('us', 'east', 'a')},
            {'name': GetZonePath('us', 'east', 'b')},
            {'name': GetZonePath('us', 'east', 'c')},
            {'name': GetZonePath('us', 'west', 'a')}]}

    class MockSharedFateZonesApi(object):
      def list(self, **unused_kwargs):
        return mock_compute_api.MockRequest(zones)

    class MockZonesApi(object):
      def list(self, **unused_kwargs):
        return mock_compute_api.MockRequest(zones)

    api = mock_compute_api.MockApi()
    api.sharedFateZones = MockSharedFateZonesApi
    api.zones = MockZonesApi
    command.SetApi(api)

    expected_zone = command.NormalizeResourceName(
        expected_project,
        zone_collection_name,
        submitted_zone)

    mock_output = mock_compute_api.MockOutput()
    mock_input = mock_compute_api.MockInput('0\n\r')
    oldin = sys.stdin
    sys.stdin = mock_input
    oldout = sys.stdout
    sys.stdout = mock_output

    result = command.Handle(expected_disk)
    self.assertEqual(result['body'][zone_field_name], expected_zone)
    sys.stdin = oldin
    sys.stdout = oldout

  def testGetDiskGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = disk_cmds.GetDisk('getdisk', flag_values)

    expected_project = 'test_project'
    expected_disk = 'test_disk'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_disk)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['disk'], expected_disk)

  def testDeleteDiskGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = disk_cmds.DeleteDisk('deletedisk', flag_values)

    expected_project = 'test_project'
    expected_disk = 'test_disk'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_disk)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['disk'], expected_disk)

  def testListDisksGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = disk_cmds.ListDisks('listdisks', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)


if __name__ == '__main__':
  unittest.main()
