#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute persistent disks."""




from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS
LOGGER = gcompute_cmd.LOGGER


class DiskCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the disks collection."""

  default_sort_field = 'name'
  summary_fields = (('name', ['name', 'id']),
                    ('description', 'description'),
                    ('zone', ['sharedFateZone', 'zone']),
                    ('size (GB)', 'sizeGb'))

  detail_fields = (('name', ['name', 'id']),
                   ('description', 'description'),
                   ('zone', ['sharedFateZone', 'zone']),
                   ('size (GB)', 'sizeGb'))

  resource_collection_name = 'disks'

  def __init__(self, name, flag_values):
    super(DiskCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._disks_api = api.disks()
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      self._zones_api = api.zones()
    else:
      self._zones_api = api.sharedFateZones()


class AddDisk(DiskCommand):
  """Create a new machine disk."""

  def __init__(self, name, flag_values):
    super(AddDisk, self).__init__(name, flag_values)
    flags.DEFINE_string('description',
                        '',
                        'Disk description.',
                        flag_values=flag_values)
    flags.DEFINE_integer('size_gb',
                         10,
                         'The size of the persistent disk in GB.',
                         lower_bound=1,
                         flag_values=flag_values)
    flags.DEFINE_string('zone',
                        None,
                        'The zone for this disk.',
                        flag_values=flag_values)

  def Handle(self, disk_name):
    """Add the specified disk.

    Args:
      disk_name: The name of the disk to add

    Returns:
      The result of inserting the disk.
    """
    if not self._flags.zone:
      self._flags.zone = self._PromptForZone()

    (zone_field_name, zone_collection_name) = self._GetZoneFieldNames()

    zone = self.NormalizeResourceName(
        self._project_id,
        zone_collection_name,
        self._flags.zone)

    disk_resource = {
        'kind': self._GetResourceApiKind('disk'),
        'name': self._DenormalizeResourceName(disk_name),
        'description': self._flags.description,
        'sizeGb': self._flags.size_gb,
        zone_field_name: zone
        }

    disk_request = self._disks_api.insert(project='%s' % self._project_id,
                                          body=disk_resource)

    return disk_request.execute()


class GetDisk(DiskCommand):
  """Get a machine disk."""

  def __init__(self, name, flag_values):
    super(GetDisk, self).__init__(name, flag_values)

  def Handle(self, disk_name):
    """Get the specified disk.

    Args:
      disk_name: The name of the disk to get

    Returns:
      The result of getting the disk.
    """
    disk_request = self._disks_api.get(
        project='%s' % self._project_id,
        disk=self._DenormalizeResourceName(disk_name))

    return disk_request.execute()


class DeleteDisk(DiskCommand):
  """Delete a machine disk."""

  safety_prompt = 'Delete disk'

  def __init__(self, name, flag_values):
    super(DeleteDisk, self).__init__(name, flag_values)

  def Handle(self, disk_name):
    """Delete the specified disk.

    Args:
      disk_name: The name of the disk to delete

    Returns:
      The result of deleting the disk.
    """
    disk_request = self._disks_api.delete(
        project='%s' % self._project_id,
        disk=self._DenormalizeResourceName(disk_name))

    return disk_request.execute()


class ListDisks(DiskCommand):
  """List the machine disks for a project."""

  def Handle(self):
    """List the project's disks.

    Args:
      None.

    Returns:
      The result of listing the disks.
    """
    disk_request = self._disks_api.list(**self._BuildListArgs())
    return disk_request.execute()


def AddCommands():
  appcommands.AddCmd('adddisk', AddDisk)
  appcommands.AddCmd('getdisk', GetDisk)
  appcommands.AddCmd('deletedisk', DeleteDisk)
  appcommands.AddCmd('listdisks', ListDisks)
