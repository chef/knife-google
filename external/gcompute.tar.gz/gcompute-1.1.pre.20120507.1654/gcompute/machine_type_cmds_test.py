#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the machine type commands."""



import copy

import gflags as flags
import unittest

from gcompute import gcompute_cmd
from gcompute import machine_type_cmds

try:
  from gcompute import mock_compute_api
except ImportError:
  import mock_compute_api

FLAGS = flags.FLAGS


class MachineTypeCmdsTest(unittest.TestCase):

  def testGetMachineTypeGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = machine_type_cmds.GetMachineType('getmachinetype', flag_values)

    expected_machine_type = 'test_machine_type'
    flag_values.service_version = gcompute_cmd.CURRENT_VERSION

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_machine_type)

    self.assertEqual(result['machineType'], expected_machine_type)


if __name__ == '__main__':
  unittest.main()
