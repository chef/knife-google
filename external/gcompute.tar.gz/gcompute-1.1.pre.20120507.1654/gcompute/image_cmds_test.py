#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the machine image commands."""



import copy

import gflags as flags
import unittest

from gcompute import gcompute_cmd
from gcompute import image_cmds
from gcompute import mock_compute_api

FLAGS = flags.FLAGS


class ImageCmdsTest(unittest.TestCase):

  def _doTestAddImageGeneratesCorrectRequest(self, service_version):
    flag_values = copy.deepcopy(FLAGS)

    command = image_cmds.AddImage('addimage', flag_values)

    expected_project = 'test_project'
    expected_image = 'test_image'
    expected_description = 'test image'
    submitted_kernel = 'projects/test_project/kernels/test_kernel'
    expected_source = 'http://test.source/'
    expected_type = 'RAW'
    flag_values.project_id = expected_project
    flag_values.description = expected_description
    flag_values.preferred_kernel = submitted_kernel
    flag_values.service_version = service_version

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    expected_kernel = command.NormalizeResourceName(expected_project,
                                                    'kernels',
                                                    submitted_kernel)

    result = command.Handle(expected_image, expected_source)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['body']['name'], expected_image)
    self.assertEqual(result['body']['description'], expected_description)

    self.assertEqual(result['body']['preferredKernel'], expected_kernel)
    self.assertEqual(result['body']['sourceType'], expected_type)
    self.assertEqual(result['body']['rawDisk']['source'], expected_source)

  def testAddImageGeneratesCorrectRequest(self):
    for version in gcompute_cmd.SUPPORTED_VERSIONS:
      self._doTestAddImageGeneratesCorrectRequest(version)

  def testGetImageGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = image_cmds.GetImage('getimage', flag_values)

    expected_project = 'test_project'
    expected_image = 'test_image'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_image)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['image'], expected_image)

  def testDeleteImageGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = image_cmds.DeleteImage('deleteimage', flag_values)

    expected_project = 'test_project'
    expected_image = 'test_image'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_image)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['image'], expected_image)

  def testListImagesGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = image_cmds.ListImages('listimages', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)


if __name__ == '__main__':
  unittest.main()
