#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Mock compute API used for unit tests."""





class CommandExecutor(object):
  """An object to represent an apiclient endpoint with a fixed response."""

  def __init__(self, response):
    """Create a new CommandExecutor to return response for each API call."""
    self._response = response

  def __call__(self, **unused_kw):
    """Handle calling this object (part 1 of making an apiclient call)."""
    return self

  def execute(self):
    """Return the stored results for this API call (part 2 of apiclient)."""
    return self._response


class MockRequest(object):
  """Mock request type for use with the MockApi class."""

  def __init__(self, result):
    self.result = result

  def execute(self):
    return self.result


class MockDisksApi(object):
  """Mock return result of the MockApi.disks() method."""

  def get(self, project='wrong_project', disk='wrong_disk'):
    return MockRequest({'project': project, 'disk': disk})

  def insert(self, project='wrong_project', body='wrong_disk_resource'):
    return MockRequest({'project': project, 'body': body})

  def delete(self, project='wrong_project', disk='wrong_disk'):
    return MockRequest({'project': project, 'disk': disk})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockFirewallsApi(object):
  """Mock return result of the MockApi.firewalls() method."""

  def get(self, project='wrong_project', firewall='wrong_firewall'):
    return MockRequest({'project': project, 'firewall': firewall})

  def insert(self, project='wrong_project', body='wrong_firewall_resource'):
    return MockRequest({'project': project, 'body': body})

  def delete(self, project='wrong_project', firewall='wrong_firewall'):
    return MockRequest({'project': project, 'firewall': firewall})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockNetworksApi(object):
  """Mock return result of the MockApi.networks() method."""

  def get(self, project='wrong_project', network='wrong_network'):
    return MockRequest({'project': project, 'network': network})

  def insert(self, project='wrong_project', body='wrong_network_resource'):
    return MockRequest({'project': project, 'body': body})

  def delete(self, project='wrong_project', network='wrong_network'):
    return MockRequest({'project': project, 'network': network})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockOperationsApi(object):
  """Mock return result of the MockApi.operations() method."""

  def get(self, project='wrong_project', operation='wrong_operation'):
    return MockRequest({'project': project, 'operation': operation})

  def delete(self, project='wrong_project', operation='wrong_operation'):
    return MockRequest({'project': project, 'operation': operation})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockImagesApi(object):
  """Mock return result of the MockApi.images() method."""

  def get(self, project='wrong_project', image='wrong_image'):
    return MockRequest({'project': project, 'image': image})

  def insert(self, project='wrong_project', body='wrong_image_resource'):
    return MockRequest({'project': project, 'body': body})

  def delete(self, project='wrong_project', image='wrong_image'):
    return MockRequest({'project': project, 'image': image})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockInstancesApi(object):
  """Mock return result of the MockApi.instances() method."""

  def get(self, project='wrong_project', instance='wrong_instance'):
    return MockRequest({'project': project, 'instance': instance})

  def insert(self, project='wrong_project', body='wrong_instance_resource'):
    return MockRequest({'project': project, 'body': body})

  def delete(self, project='wrong_project', instance='wrong_instance'):
    return MockRequest({'project': project, 'instance': instance})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockKernelsApi(object):
  """Mock return result of the MockApi.kernels() method."""

  def get(self, project='wrong_project', kernel='wrong_kernel'):
    return MockRequest({'project': project, 'kernel': kernel})

  def list(self, project='wrong_project'):
    return MockRequest({'project': project})


class MockMachineSpecsApi(object):
  """Mock return result of the MockApi.machineSpecs() method."""

  def get(self, machineSpec='wrong_machine_type'):
    return MockRequest({'machineSpec': machineSpec})

  def list(self):
    return MockRequest('empty_result')


class MockMachineTypesApi(object):
  """Mock return result of the MockApi.machineTypes() method."""

  def get(self, machineType='wrong_machine_type', **unused_kwargs):
    return MockRequest({'machineType': machineType})

  def list(self, **unused_kwargs):
    return MockRequest('empty_result')


class MockProjectsApi(object):
  """Mock return result of the MockApi.projects() method."""

  def get(self, project='wrong_project'):
    return MockRequest({'project': project})

  def setCommonInstanceMetadata(self, project='wrong_project', body=None):
    return MockRequest({'project': project, 'commonInstanceMetadata': body})


class MockSharedFateZonesApi(object):
  """Mock return result of the MockApi.sharedFateZones() method."""

  def get(self, region='wrong_region', scd='wrong_scd', sfz='wrong_sfz',
          **unused_kwargs):
    return MockRequest({'region': region, 'scd': scd, 'sfz': sfz})

  def list(self, **unused_kwargs):
    return MockRequest('empty_result')


class MockZonesApi(object):
  """Mock return result of the MockApi.zones() method."""

  def get(self, zone='wrong_zone', **unused_kwargs):
    return MockRequest({'zone': zone})

  def list(self, **unused_kwargs):
    return MockRequest('empty_result')


class MockApi(object):
  """Mock of the Google Compute API returned by the discovery client."""

  def disks(self):
    return MockDisksApi()

  def firewalls(self):
    return MockFirewallsApi()

  def networks(self):
    return MockNetworksApi()

  def images(self):
    return MockImagesApi()

  def instances(self):
    return MockInstancesApi()

  def kernels(self):
    return MockKernelsApi()

  def machineSpecs(self):
    return MockMachineSpecsApi()

  def machineTypes(self):
    return MockMachineTypesApi()

  def projects(self):
    return MockProjectsApi()

  def sharedFateZones(self):
    return MockSharedFateZonesApi()

  def operations(self):
    return MockOperationsApi()

  def zones(self):
    return MockZonesApi()


class MockOutput(object):
  """Mock class used for capturing standard output in tests."""

  def __init__(self):
    self._capture_text = ''

  # Purposefully name this 'write' to mock an output stream
  # pylint: disable-msg=C6409
  def write(self, text):
    self._capture_text += text

  # Purposefully name this 'flush' to mock an output stream
  # pylint: disable-msg=C6409
  def flush(self):
    pass

  def GetCapturedText(self):
    return self._capture_text


class MockInput(object):
  """Mock class for standard input in tests."""

  def __init__(self, input_string):
    self._input_string = input_string

  # Purposefully name this 'readline' to mock an input stream
  # pylint: disable-msg=C6409
  def readline(self):
    return self._input_string
