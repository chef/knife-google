#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute machine images."""





from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS



class ImageCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the images collection."""

  default_sort_field = 'name'
  summary_fields = (('name', ['name', 'id']),
                    ('description', 'description'),
                    ('kernel', ['preferredKernel', 'preferred_kernel']),
                    ('size (GB)', ['tarDisk.sizeGb', 'tar_disk.size_gb']),
                    ('type', ['sourceType', 'source_type']))

  detail_fields = (('name', ['name', 'id']),
                   ('description', 'description'),
                   ('kernel', ['preferredKernel', 'preferred_kernel']),
                   ('size (GB)', ['tarDisk.sizeGb', 'tar_disk.size_gb']),
                   ('type', ['sourceType', 'source_type']))

  resource_collection_name = 'images'

  def __init__(self, name, flag_values):
    super(ImageCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.
    """
    self._images_api = api.images()


class AddImage(ImageCommand):
  """Create a new machine image.

  The root_source_tarball parameter must point to a tar file of the
  contents of the desired root directory stored in Google Storage.
  """

  def __init__(self, name, flag_values):
    super(AddImage, self).__init__(name, flag_values)
    flags.DEFINE_string('description',
                        '',
                        'Image description',
                        flag_values=flag_values)
    flags.DEFINE_string('preferred_kernel',
                        None,
                        'Kernel name',
                        flag_values=flag_values)

  def Handle(self, image_name, root_source_tarball):
    """Add the specified image.

    Args:
      image_name: The name of the image to add.
      root_source_tarball: Tarball in Google Storage containing the
        desired root directory for the resulting image.

    Returns:
      The result of inserting the image.
    """

    image_resource = {
        'kind': self._GetResourceApiKind('image'),
        'name': self._DenormalizeResourceName(image_name),
        'description': self._flags.description
        }

    image_resource['sourceType'] = 'RAW'

    if self._flags.preferred_kernel:
      kernel_name = self.NormalizeResourceName(self._project_id,
                                               'kernels',
                                               self._flags.preferred_kernel)
      image_resource['preferredKernel'] = kernel_name

    image_resource['rawDisk'] = {
        'source': root_source_tarball,
        'containerType': 'TAR'
        }

    image_request = self._images_api.insert(project=self._project_id,
                                            body=image_resource)
    return image_request.execute()


class GetImage(ImageCommand):
  """Get a machine image."""

  def __init__(self, name, flag_values):
    super(GetImage, self).__init__(name, flag_values)

  def Handle(self, image_name):
    """GSet the specified image.

    Args:
      image_name: The name of the image to get.

    Returns:
      The result of getting the image.
    """
    image_request = self._images_api.get(
        project=self._project_id,
        image=self._DenormalizeResourceName(image_name))

    return image_request.execute()


class DeleteImage(ImageCommand):
  """Delete a machine image."""

  safety_prompt = 'Delete image'

  def __init__(self, name, flag_values):
    super(DeleteImage, self).__init__(name, flag_values)

  def Handle(self, image_name):
    """Delete the specified image.

    Args:
      image_name: The name of the image to add.

    Returns:
      The result of deleting the image.
    """
    image_request = self._images_api.delete(
        project=self._project_id,
        image=self._DenormalizeResourceName(image_name))

    return image_request.execute()


class ListImages(ImageCommand):
  """List the machine images for a project."""

  def Handle(self):
    """List the project's images.

    Args:
      None.

    Returns:
      The result of listing the images.
    """
    image_request = self._images_api.list(**self._BuildListArgs())
    return image_request.execute()


def AddCommands():
  appcommands.AddCmd('addimage', AddImage)
  appcommands.AddCmd('getimage', GetImage)
  appcommands.AddCmd('deleteimage', DeleteImage)
  appcommands.AddCmd('listimages', ListImages)
