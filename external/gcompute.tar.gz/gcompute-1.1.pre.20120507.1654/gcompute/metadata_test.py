#!/usr/bin/env python
#
# Copyright 2011 Google Inc. All Rights Reserved.
#

"""Unit tests for the metadata package."""

from __future__ import with_statement



import copy
import tempfile

import gflags as flags
import unittest

from gcompute import metadata


FLAGS = flags.FLAGS


class MetadataTest(unittest.TestCase):
  def testGatherMetadata(self):
    flag_values = copy.deepcopy(FLAGS)
    metadata_flags_processor = metadata.MetadataFlagsProcessor(flag_values)

    with tempfile.NamedTemporaryFile() as metadata_file:
      metadata_file.write('metadata file content')
      metadata_file.flush()

      flag_values.metadata = ['bar:baz']
      flag_values.metadata_from_file = ['bar_file:%s' % metadata_file.name]

      metadata_entries = metadata_flags_processor.GatherMetadata()

      self.assertEqual(len(metadata_entries), 2)
      self.assertEqual(metadata_entries[0]['key'], 'bar')
      self.assertEqual(metadata_entries[0]['value'], 'baz')
      self.assertEqual(metadata_entries[1]['key'], 'bar_file')
      self.assertEqual(metadata_entries[1]['value'],
                       'metadata file content')


if __name__ == '__main__':
  unittest.main()
