#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute."""




from google.apputils import appcommands
import gflags as flags

from gcompute import auth_helper
from gcompute import gcompute_cmd
from gcompute import metadata
from gcompute import scopes
from gcompute import version

import httplib2

try:
  import json
except ImportError, err:
  import simplejson as json

FLAGS = flags.FLAGS
LOGGER = gcompute_cmd.LOGGER


class AuthCommand(gcompute_cmd.GoogleComputeCommand):
  """Class for forcing client authorization."""

  def __init__(self, name, flag_values):
    super(AuthCommand, self).__init__(name, flag_values)
    flags.DEFINE_boolean('force_reauth',
                         True,
                         'If True, will force user to reauthorize',
                         flag_values=flag_values)
    flags.DEFINE_boolean('just_check_auth',
                         False,
                         'If True, just check if auth exists',
                         flag_values=flag_values)
    flags.DEFINE_boolean('confirm_email',
                         True,
                         'Get info about the user and echo the email',
                         flag_values=flag_values)

  def RunWithFlagsAndPositionalArgs(self,
                                    flag_values,
                                    unused_pos_arg_values):
    """Run the command, returning the result.

    Args:
      flag_values: The parsed FlagValues instance.
      unused_pos_arg_values: The positional args.

    Returns:
      0 if the command completes successfully, otherwise 1.
    """
    cred = auth_helper.GetCredentialFromStore(
        scopes=scopes.DEFAULT_AUTH_SCOPES,
        ask_user=not flag_values.just_check_auth,
        force_reauth=flag_values.force_reauth)
    if not cred:
      raise gcompute_cmd.CommandError(
          'Could not get valid credentials for API.')

    if flag_values.confirm_email:
      http = self._AuthenticateWrapper(httplib2.Http())
      resp, content = http.request(
          'https://www.googleapis.com/userinfo/v2/me', 'GET')
      if resp.status != 200:
        LOGGER.info('Could not get user info for token.  <%d %s>',
                    resp.status, resp.reason)
      userinfo = json.loads(content)
      if 'email' in userinfo and userinfo['email']:
        LOGGER.info('Authorization succeeded for user %s', userinfo['email'])
      else:
        LOGGER.info('Could not get email for token.')
    else:
      LOGGER.info('Authentication succeeded.')
    return 0

  def PrintResult(self, result):
    """Print the result of the authentication command.

    Args:
      result: The result of the authentication command.
    """
    pass


class GetProject(gcompute_cmd.GoogleComputeCommand):
  """Get the resource for a Google Compute project."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'),
                    ('ips', 'externalIpAddresses'))

  # The remaining complex fields are filled in via CustomizePrintResult
  detail_fields = (('name', 'name'),
                   ('description', 'description'),
                   ('ips', 'externalIpAddresses'))

  def __init__(self, name, flag_values):
    super(GetProject, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._projects_api = api.projects()

  def Handle(self):
    """Get the specified project.

    Args:
      None.

    Returns:
      The result of getting the project.
    """
    project_request = self._projects_api.get(project=self._flags.project_id)
    return project_request.execute()

  def CustomizePrintResult(self, result, table):
    """Customized result printing for this type.

    Args:
      result: json dictionary returned by the server
      table: the pretty printing table to be customized

    Returns:
      None.

    """
    # Add the quotas
    for quota in result.get('quotas', []):
      table.add_row(('%s quota usage / limit' % quota['metric'],
                     '%s / %s' % (str(quota['usage']), str(quota['limit']))))
    # Add the metadata
    if result.get('commonInstanceMetadata', []):
      table.add_row(('', ''))
      table.add_row(('Common Instance Metadata', ''))
      metadata_container = result.get('commonInstanceMetadata', [])
      if 'kind' in metadata_container:
        metadata_container = metadata_container.get('metadata', [])
      for metadata_entry in metadata_container:
        table.add_row(('  %s' % metadata_entry.get('key', ''),
                       self._PresentElement(metadata_entry.get('value', ''))))


class SetCommonInstanceMetadata(gcompute_cmd.GoogleComputeCommand):
  """Set the commonInstanceMetadata field for a Google Compute project.

  This is a blanket overwrite of all of the project wide metadata.
  """

  def __init__(self, name, flag_values):
    super(SetCommonInstanceMetadata, self).__init__(name, flag_values)
    flags.DEFINE_bool('force',
                      False,
                      'Set the metadata even if it erases existing keys',
                      flag_values=flag_values,
                      short_name='f')
    self._metadata_flags_processor = metadata.MetadataFlagsProcessor(
        flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._projects_api = api.projects()

  def Handle(self):
    """Set the metadata common to all instances in the specified project.

    Args:
      None.

    Returns:
      The result of setting the project wide metadata.
    """
    new_metadata = self._metadata_flags_processor.GatherMetadata()

    if not self._flags.force:
      get_request = self._projects_api.get(project=self._flags.project_id)
      project_resource = get_request.execute()
      project_metadata = project_resource.get('commonInstanceMetadata', [])
      if 'kind' in project_metadata:
        project_metadata = project_metadata.get('metadata', [])
      existing_keys = set([entry['key'] for entry in project_metadata])
      new_keys = set([entry['key'] for entry in new_metadata])
      dropped_keys = existing_keys - new_keys
      if dropped_keys:
        raise gcompute_cmd.CommandError(
            'Discarding update that would wipe out the following metadata: %s.'
            '\n\nRe-run with the -f flag to force the update.' %
            ', '.join(list(dropped_keys)))

    metadata_resource_type = 'setMetadata'

    if self._IsUsingAtLeastApiVersion('v1beta11'):
      metadata_resource_type = 'metadata'

    project_request = self._projects_api.setCommonInstanceMetadata(
        project=self._flags.project_id,
        body={'kind': self._GetResourceApiKind(metadata_resource_type),
              'metadata': new_metadata})
    return project_request.execute()


class GetVersion(gcompute_cmd.GoogleComputeCommand):
  """Get the current version of this command."""

  def __init__(self, name, flag_values):
    super(GetVersion, self).__init__(name, flag_values)

  def Run(self, unused_argv):
    """Return the current version information for gcompute.

    Args:
      None expected.

    Returns:
      Version of this command.
    """
    print version.__version__
    return 0


def AddCommands():
  appcommands.AddCmd('auth', AuthCommand)
  appcommands.AddCmd('getproject', GetProject)
  appcommands.AddCmd('setcommoninstancemetadata', SetCommonInstanceMetadata)
  appcommands.AddCmd('version', GetVersion)
