#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute availability zones."""



import datetime
import iso8601
import pytz

from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS


class ZoneCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the zones collection."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'),
                    ('status', 'status'),
                    ('next maintenance window start time',
                     'next_maintenance_window'))

  detail_fields = (('name', 'name'),
                   ('description', 'description'),
                   ('status', 'status'))

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.
    """
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      self._zones_api = api.zones()
    else:
      self._zones_api = api.sharedFateZones()

  def _GetZoneNameParts(self, zone_name):
    """Get the name for the zone resource given the flag values.

    Args:
      zone_name: Path of the zone to parse.

    Returns:
      The name of the zone resource, structured as a tuple of jurisdiction,
      region, and zone. This will be deprecated in a future API.

    Raises:
      gcompute_cmd.CommandError: If the flag values cannot be used to derive a
          well formed zone name.
    """
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      return zone_name

    prefix = 'shared-fate-zones/'
    splitter = '/'

    name = zone_name.strip('/')
    if name.startswith(prefix):
      name = name[len(prefix):]

    name_parts = name.split(splitter)
    if (len(name_parts) == 3 and
        name_parts[0] and
        name_parts[1] and
        name_parts[2]):
      return (name_parts[0], name_parts[1], name_parts[2])

    raise gcompute_cmd.CommandError(
        'You must specify a fully qualified zone name.')


class GetZone(ZoneCommand):
  """Get a zone."""

  def CustomizePrintResult(self, result, table):
    """Customized result printing for this type.

    Args:
      result: json dictionary returned by the server
      table: the pretty printing table to be customized

    Returns:
      None.

    """
    # Add the maintenance windows
    table.add_row(('maintenance windows', ''))
    for window in result.get('maintenanceWindows', []):
      table.add_row(('', ''))
      table.add_row(('  name', window['name']))
      table.add_row(('  description', window['description']))
      table.add_row(('  begin time', window['beginTime']))
      table.add_row(('  end time', window['endTime']))

  def Handle(self, zone_name):
    """Get the specified zone.

    Args:
      zone_name: Path of the zone to get.

    Returns:
      The result of getting the zone.
    """
    if self._IsUsingAtLeastApiVersion('v1beta11'):
      request = self._zones_api.get(project=self._project_id, zone=zone_name)
    else:
      (jurisdiction, region, zone) = self._GetZoneNameParts(zone_name)
      request = self._zones_api.get(project=self._project_id,
                                    region=jurisdiction,
                                    scd=region,
                                    sfz=zone)
    return request.execute()


class ListZones(ZoneCommand):
  """List available zones."""

  def Handle(self):
    """List the zones.

    Args:
      None.

    Returns:
      The result of getting the zones.
    """
    request = self._zones_api.list(**self._BuildListArgs())
    result = request.execute()

    # Add the next maintenance window start time to each entry
    # As a comparator, generate the maximum datetime, including timezone.
    max_datetime = datetime.datetime.max.replace(tzinfo=pytz.UTC)
    for zone in result.get('items', []):
      next_start_time = max_datetime

      for window in zone.get('maintenanceWindows', []):
        begin_time = iso8601.parse_date(window['beginTime'])
        if begin_time < next_start_time:
          next_start_time = begin_time

      if next_start_time != max_datetime:
        zone['next_maintenance_window'] = next_start_time
      else:
        zone['next_maintenance_window'] = 'None scheduled'

    return result


def AddCommands():
  appcommands.AddCmd('getzone', GetZone)
  appcommands.AddCmd('listzones', ListZones)
