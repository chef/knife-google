#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute operations."""



from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS


class OperationCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the operations collection.

  Attributes:
    default_sort_field: The json field name used to sort list output for the
        command.
    summary_fields: A set of tuples of (json field name, human
        readable name) used to generate a pretty-printed summary description
        of a list of operation resources.
    detail_fields: A set of tuples of (json field name, human
        readable name) used to generate a pretty-printed detailed description
        of an operation resource.
    resource_collection_name: The name of the REST API collection handled by
        this command type.
  """

  default_sort_field = 'insertTime'
  summary_fields = (('name', 'name'),
                    ('status', 'status'),
                    ('progress', 'progress'),
                    ('statusMessage', 'statusMessage'),
                    ('target', 'targetLink'),
                    ('client operation id', 'clientOperationId'),
                    ('insertTime', 'insertTime'),
                    ('startTime', 'startTime'),
                    ('endTime', 'endTime'),
                    ('operationType', 'operationType'),
                    ('error', 'error.errors.code'))

  detail_fields = gcompute_cmd.GoogleComputeCommand.operation_detail_fields

  resource_collection_name = 'operations'

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.
    """
    self._operations_api = api.operations()


class GetOperation(OperationCommand):
  """Retrieve an operation resource."""

  def Handle(self, operation_name):
    """Get the specified operation.

    Args:
      operation_name: The name of the operation to get.

    Returns:
      The json formatted object resulting from retrieving the operation
      resource.
    """
    # Force asynchronous mode so the caller doesn't wait for this operation
    # to complete before returning.
    self._flags.synchronous_mode = False

    operation_request = self._operations_api.get(
        project=self._project_id,
        operation=self._DenormalizeResourceName(operation_name))

    return operation_request.execute()


class DeleteOperation(OperationCommand):
  """Delete an operation."""

  safety_prompt = 'Delete operation'

  def Handle(self, operation_name):
    """Delete the specified operation.

    Args:
      operation_name: The name of the operation to get.

    Returns:
      The json formatted object resulting from deleting the operation resource.
    """
    operation_request = self._operations_api.delete(
        project=self._project_id,
        operation=self._DenormalizeResourceName(operation_name))

    return operation_request.execute()


class ListOperations(OperationCommand):
  """List the operations for a project."""

  def __init__(self, name, flag_values):
    super(ListOperations, self).__init__(name, flag_values)
    flags.DEFINE_string('filter_target',
                        None,
                        'Filter the operations list result by target link',
                        flag_values=flag_values)

  def Handle(self):
    """List the project's operations.

    Returns:
      The json formatted object resulting from listing the operation resources.
    """
    operation_request = self._operations_api.list(**self._BuildListArgs())
    return operation_request.execute()


def AddCommands():
  appcommands.AddCmd('getoperation', GetOperation)
  appcommands.AddCmd('deleteoperation', DeleteOperation)
  appcommands.AddCmd('listoperations', ListOperations)
