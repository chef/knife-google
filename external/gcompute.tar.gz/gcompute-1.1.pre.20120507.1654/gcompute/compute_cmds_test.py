#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the compute commands."""



import copy
import re
import tempfile


import gflags as flags
import unittest

from gcompute import auth_helper
from gcompute import compute_cmds
from gcompute import flags_cache
from gcompute import gcompute_cmd
from gcompute import mock_compute_api

FLAGS = flags.FLAGS


class ComputeCmdsTest(unittest.TestCase):
  def testAuthDoesNotBuildApi(self):
    class MockFlagsCache(object):
      """Mock FlagsCache for testing."""

      def SynchronizeFlags(self):
        """Mock SynchronizeFlags method that does nothing."""
        pass

    class MockCredential(object):
      """Mock OAuth2 Credential."""

      def authorize(self, http):
        """Authorize an http2.Http instance with this credential.

        Args:
          http: httplib2.http to append authorization to.

        Returns:
          An httplib2.http compatible object.
        """
        return http

    def MockGetCredentialFromStore(scopes,
                                   ask_user,
                                   force_reauth):
      """Returns a mock cred.

      Args:
        scopes: Scopes for which auth is being requested.
        ask_user: Should the user be asked to auth?
        force_reauth: Force user to reauth.

      Returns:
        A credentials object.
      """
      force_reauth = force_reauth  # silence lint
      ask_user = ask_user
      scopes = scopes
      return MockCredential()

    flag_values = copy.deepcopy(FLAGS)
    flags_cache.FlagsCache = MockFlagsCache
    auth_helper.GetCredentialFromStore = MockGetCredentialFromStore

    command = compute_cmds.AuthCommand('auth', flag_values)

    flag_values.fetch_discovery = False
    flag_values.api_host = None
    flag_values.service_version = None
    flag_values.project_id = None
    flag_values.force_reauth = True
    flag_values.confirm_email = False

    command.SetFlags(flag_values)
    result = command.RunWithFlagsAndPositionalArgs(flag_values,
                                                   ['path/to/gcompute'])
    self.assertEqual(result, 0)

  def testGetProjectGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = compute_cmds.GetProject('getproject', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)

  def testSetCommonInstanceMetadataGeneratesCorrectRequest(self):

    class SetCommonInstanceMetadata(object):

      def __call__(self, project, body):
        self._project = project
        self._body = body
        return self

      def execute(self):
        return {'project': self._project, 'body': self._body}

    flag_values = copy.deepcopy(FLAGS)
    command = compute_cmds.SetCommonInstanceMetadata(
        'setcommoninstancemetadata', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project
    flag_values.service_version = 'v1beta11'
    with tempfile.NamedTemporaryFile() as metadata_file:
      metadata_file.write('foo:bar')
      metadata_file.flush()
      flag_values.metadata_from_file = ['sshKeys:%s' % metadata_file.name]

      command.SetFlags(flag_values)
      command.SetApi(mock_compute_api.MockApi())
      command._projects_api.get = mock_compute_api.CommandExecutor(
          {'commonInstanceMetadata': [{'key': 'sshKeys', 'value': ''}]})
      command._projects_api.setCommonInstanceMetadata = (
          SetCommonInstanceMetadata())

      result = command.Handle()
      self.assertEquals(expected_project, result['project'])
      self.assertEquals(
          {'kind': 'compute#metadata',
           'metadata': [{'key': 'sshKeys', 'value': 'foo:bar'}]},
          result['body'])

  def testSetCommonInstanceMetadataChecksForOverwrites(self):
    flag_values = copy.deepcopy(FLAGS)
    command = compute_cmds.SetCommonInstanceMetadata(
        'setcommoninstancemetadata', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project
    flag_values.service_version = 'v1beta11'
    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())
    command._projects_api.get = mock_compute_api.CommandExecutor(
        {'commonInstanceMetadata': [{'key': 'sshKeys', 'value': 'foo:bar'}]})

    self.assertRaises(
        gcompute_cmd.CommandError,
        command.Handle)

  def testGetVersionGeneratesCorrectResponse(self):

    def CheckExternalVersion():
      """Check that external version string matches expected format.

      Returns:
        match object or None if the string is incorrectly formated
      """
      return re.match('^\d+\.\d+(\.\d+)?$', compute_cmds.version.__version__)

    flag_values = copy.deepcopy(FLAGS)

    command = compute_cmds.GetVersion('version', flag_values)

    result = command.Run([])

    self.assertEqual(result, 0)
    self.assert_(CheckExternalVersion())

if __name__ == '__main__':
  unittest.main()
