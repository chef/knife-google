#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the firewall commands."""



import copy

import gflags as flags
import unittest

from gcompute import firewall_cmds
from gcompute import gcompute_cmd
from gcompute import mock_compute_api

FLAGS = flags.FLAGS


class FirewallRulesTest(unittest.TestCase):
  def testParseProtocol(self):
    parse_protocol = firewall_cmds.FirewallRules.ParseProtocol
    self.assertRaises(ValueError, parse_protocol, None)
    self.assertRaises(ValueError, parse_protocol, '')
    self.assertRaises(ValueError, parse_protocol, 'foo')

    self.assertEqual(parse_protocol(6), 6)
    self.assertEqual(parse_protocol('6'), 6)
    self.assertEqual(parse_protocol('tcp'), 6)
    self.assertEqual(parse_protocol('udp'), 17)

  def testReplacePortNames(self):
    replace_port_names = firewall_cmds.FirewallRules.ReplacePortNames
    self.assertRaises(ValueError, replace_port_names, None)
    self.assertRaises(ValueError, replace_port_names, 22)
    self.assertRaises(ValueError, replace_port_names, '')
    self.assertRaises(ValueError, replace_port_names, 'foo')
    self.assertRaises(ValueError, replace_port_names, 'foo-bar')
    self.assertRaises(ValueError, replace_port_names, '24-42-2442')

    self.assertEqual(replace_port_names('ssh'), '22')
    self.assertEqual(replace_port_names('22'), '22')
    self.assertEqual(replace_port_names('ssh-http'), '22-80')
    self.assertEqual(replace_port_names('22-http'), '22-80')
    self.assertEqual(replace_port_names('ssh-80'), '22-80')
    self.assertEqual(replace_port_names('22-80'), '22-80')

  def testParsePortSpecs(self):
    parse_port_specs = firewall_cmds.FirewallRules.ParsePortSpecs
    self.assertRaises(ValueError, parse_port_specs, [''])
    self.assertRaises(ValueError, parse_port_specs, ['foo'])
    self.assertRaises(ValueError, parse_port_specs, ['foo:'])
    self.assertRaises(ValueError, parse_port_specs, ['tcp:foo-bar'])
    self.assertRaises(ValueError, parse_port_specs, ['tcp:http:https'])

    self.assertEqual(parse_port_specs([]), [])
    self.assertEqual(parse_port_specs(['tcp']),
                     [{'IPProtocol': '6'}])
    self.assertEqual(parse_port_specs(['6']),
                     [{'IPProtocol': '6'}])
    self.assertEqual(parse_port_specs(['tcp:80', 'tcp', 'tcp:ssh']),
                     [{'IPProtocol': '6'}])
    self.assertEqual(parse_port_specs(['tcp:ssh']),
                     [{'IPProtocol': '6',
                       'ports': ['22']}])
    self.assertEqual(parse_port_specs([':ssh']),
                     [{'IPProtocol': '17',
                       'ports': ['22']},
                      {'IPProtocol': '6',
                       'ports': ['22']}])
    self.assertEqual(parse_port_specs([':ssh']),
                     parse_port_specs(['udp:ssh', 'tcp:ssh']))
    self.assertEqual(parse_port_specs([':ssh', 'tcp:80']),
                     [{'IPProtocol': '17',
                       'ports': ['22']},
                      {'IPProtocol': '6',
                       'ports': ['22', '80']}])


class FirewallCmdsTest(unittest.TestCase):

  def _doAddFirewallGeneratesCorrectRequest(self, service_version,
                                            allowed_ip_source):
    flag_values = copy.deepcopy(FLAGS)

    command = firewall_cmds.AddFirewall('addfirewall', flag_values)

    expected_project = 'test_project'
    expected_firewall = 'test_firewall'
    submitted_network = 'test_network'
    expected_description = 'test firewall'
    flag_values.service_version = service_version
    flag_values.project_id = expected_project
    flag_values.description = expected_description
    flag_values.network = submitted_network
    flag_values.allowed = [':22']
    if allowed_ip_source:
      flag_values.allowed_ip_sources.append(allowed_ip_source)

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    expected_network = command.NormalizeResourceName(expected_project,
                                                     'networks',
                                                     submitted_network)

    result = command.Handle(expected_firewall)

    self.assertEqual(result['project'], expected_project)

    response_body = result['body']
    self.assertEqual(response_body['name'], expected_firewall)
    self.assertEqual(response_body['network'], expected_network)
    self.assertEqual(response_body['description'], expected_description)

    rules = response_body['rules']
    self.assertEqual(len(rules), 2)
    used_protocols = set([rules[0]['IPProtocol'], rules[1]['IPProtocol']])
    self.assertEqual(used_protocols, set(['6', '17']))
    self.assertEqual(rules[0]['ports'], rules[1]['ports'])
    self.assertEqual(rules[0]['ports'], ['22'])
    self.assertEqual(rules[0]['source'], rules[1]['source'])
    if allowed_ip_source:
      self.assertEqual(rules[0]['source'], allowed_ip_source)
    else:
      self.assertEqual(rules[0]['source'], '0.0.0.0/0')

  def testAddFirewallGeneratesCorrectRequest(self):
    for version in gcompute_cmd.SUPPORTED_VERSIONS:
      self._doAddFirewallGeneratesCorrectRequest(version, '10.10.10.10/0')

  def testAddFirewallGeneratesCorrectRequestWithNoAllowedIpSource(self):
    for version in gcompute_cmd.SUPPORTED_VERSIONS:
      self._doAddFirewallGeneratesCorrectRequest(version,
                                                 allowed_ip_source=None)

  def testGetFirewallGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = firewall_cmds.GetFirewall('getfirewall', flag_values)

    expected_project = 'test_project'
    expected_firewall = 'test_firewall'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_firewall)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['firewall'], expected_firewall)

  def testDeleteFirewallGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = firewall_cmds.DeleteFirewall('deletefirewall', flag_values)

    expected_project = 'test_project'
    expected_firewall = 'test_firewall'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_firewall)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['firewall'], expected_firewall)

  def testListFirewallsGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = firewall_cmds.ListFirewalls('listfirewalls', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)



if __name__ == '__main__':
  unittest.main()
