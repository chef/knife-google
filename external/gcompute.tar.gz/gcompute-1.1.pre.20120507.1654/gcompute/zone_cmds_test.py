#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the zone commands."""



import copy

import gflags as flags
import unittest

from gcompute import gcompute_cmd
from gcompute import mock_compute_api
from gcompute import zone_cmds

FLAGS = flags.FLAGS


class ZoneCmdsTest(unittest.TestCase):

  def testGetZoneGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = zone_cmds.GetZone('getzone', flag_values)

    expected_jurisdiction = 'test_jurisdiction'
    expected_region = 'test_region'
    expected_zone = 'z'
    submitted_full_zone = '%s-%s-%s' % (expected_jurisdiction,
                                        expected_region,
                                        expected_zone)
    flag_values.service_version = gcompute_cmd.CURRENT_VERSION

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(submitted_full_zone)

    self.assertEqual(result['zone'], submitted_full_zone)

  def testZonePathParsingAbsolute(self):
    flag_values = copy.deepcopy(FLAGS)
    flag_values.service_version = 'v1beta10'

    command = zone_cmds.ZoneCommand('getzone', flag_values)

    expected_jurisdiction = 'test_jurisdiction'
    expected_region = 'test_region'
    expected_zone = 'test_zone'
    absolute_path = '%s/%s/%s' % (expected_jurisdiction,
                                  expected_region,
                                  expected_zone)

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    (jurisdiction, region, zone) = command._GetZoneNameParts(absolute_path)

    self.assertEqual(jurisdiction, expected_jurisdiction)
    self.assertEqual(region, expected_region)
    self.assertEqual(zone, expected_zone)

  def testZonePathParsingInvalid(self):
    flag_values = copy.deepcopy(FLAGS)
    flag_values.service_version = 'v1beta10'

    command = zone_cmds.GetZone('getzone', flag_values)

    expected_zone = 'test_zone'
    # Don't set the jurisdiction & region flags.

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    self.assertRaises(gcompute_cmd.CommandError,
                      command._GetZoneNameParts,
                      expected_zone)


if __name__ == '__main__':
  unittest.main()
