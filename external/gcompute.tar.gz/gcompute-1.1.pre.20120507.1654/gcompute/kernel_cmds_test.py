#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Unit tests for the kernel commands."""



import copy

import gflags as flags
import unittest

from gcompute import kernel_cmds
from gcompute import mock_compute_api

FLAGS = flags.FLAGS


class KernelCmdsTest(unittest.TestCase):

  def testGetKernelGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = kernel_cmds.GetKernel('getkernel', flag_values)

    expected_project = 'test_project'
    expected_kernel = 'test_kernel'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle(expected_kernel)

    self.assertEqual(result['project'], expected_project)
    self.assertEqual(result['kernel'], expected_kernel)

  def testListKernelsGeneratesCorrectRequest(self):
    flag_values = copy.deepcopy(FLAGS)

    command = kernel_cmds.ListKernels('listkernels', flag_values)

    expected_project = 'test_project'
    flag_values.project_id = expected_project

    command.SetFlags(flag_values)
    command.SetApi(mock_compute_api.MockApi())

    result = command.Handle()

    self.assertEqual(result['project'], expected_project)


if __name__ == '__main__':
  unittest.main()
