#!/usr/bin/env python
# Copyright 2012 Google Inc. All Rights Reserved.

"""The Google API scopes used by gcompute."""



USER_INFO_SCOPE = 'https://www.googleapis.com/auth/userinfo.email'
COMPUTE_RW_SCOPE = 'https://www.googleapis.com/auth/compute'
COMPUTE_RO_SCOPE = 'https://www.googleapis.com/auth/compute.readonly'
STORAGE_R_SCOPE = 'https://www.googleapis.com/auth/devstorage.read_only'
STORAGE_W_SCOPE = 'https://www.googleapis.com/auth/devstorage.write_only'
STORAGE_RW_SCOPE = (
        'https://www.googleapis.com/auth/devstorage.read_write')
STORAGE_FULL_SCOPE = 'https://www.googleapis.com/auth/devstorage.full_control'
DEFAULT_AUTH_SCOPES = [
    COMPUTE_RW_SCOPE, COMPUTE_RO_SCOPE,
    # USER_INFO_SCOPE allows seeing who user authenticated as.
    USER_INFO_SCOPE,
    # Image commands use STORAGE access.
    STORAGE_R_SCOPE, STORAGE_W_SCOPE, STORAGE_RW_SCOPE, STORAGE_FULL_SCOPE
    ]
