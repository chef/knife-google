#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Commands for interacting with Google Compute installed kernels."""




from google.apputils import appcommands
import gflags as flags

from gcompute import gcompute_cmd

FLAGS = flags.FLAGS



class KernelCommand(gcompute_cmd.GoogleComputeCommand):
  """Base command for working with the kernels collection."""

  default_sort_field = 'name'
  summary_fields = (('name', 'name'),
                    ('description', 'description'))

  detail_fields = (('name', 'name'),
                   ('description', 'description'))

  resource_collection_name = 'kernels'

  def __init__(self, name, flag_values):
    super(KernelCommand, self).__init__(name, flag_values)

  def SetApi(self, api):
    """Set the Google Compute API for the command.

    Args:
      api: The Google Compute API used by this command.

    Returns:
      None.

    """
    self._kernels_api = api.kernels()


class GetKernel(KernelCommand):
  """Get a kernel."""

  def __init__(self, name, flag_values):
    super(GetKernel, self).__init__(name, flag_values)

  def Handle(self, kernel_name):
    """Get the specified kernel.

    Args:
      kernel_name: The name of the kernel to get.

    Returns:
      The result of getting the kernel.
    """
    kernel_request = self._kernels_api.get(
        project=self._project_id,
        kernel=self._DenormalizeResourceName(kernel_name))

    return kernel_request.execute()


class ListKernels(KernelCommand):
  """List the machine kernels for a project."""

  def Handle(self):
    """List the project's kernels.

    Args:
      None.

    Returns:
      The result of listing the kernels.
    """
    kernel_request = self._kernels_api.list(**self._BuildListArgs())
    return kernel_request.execute()


def AddCommands():
  appcommands.AddCmd('getkernel', GetKernel)
  appcommands.AddCmd('listkernels', ListKernels)
