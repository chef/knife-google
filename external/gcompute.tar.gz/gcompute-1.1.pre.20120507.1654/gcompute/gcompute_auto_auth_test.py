#!/usr/bin/env python
#
# Copyright 2011 Google Inc. All Rights Reserved.
#

"""Tests for gcompute_auto_auth."""



import datetime

import unittest
from gcompute import gcompute_auto_auth
from gcompute import metadata_lib_test_utils

SCOPE1 = 'https://www.googleapis.com/auth/compute'
SCOPE2 = 'https://www.googleapis.com/auth/devstorage.full_control'

class GcomputeAutoAuthTest(unittest.TestCase):

  def testCredentials(self):
    metadata = metadata_lib_test_utils.MockMetadata()

    token1 = 'access token1'
    expiry1 = datetime.datetime(1970, 1, 1)
    token2 = 'access token2'
    expiry2 = datetime.datetime(1970, 1, 2)

    metadata.ExpectGetAccessScopes([SCOPE1, SCOPE2])
    metadata.ExpectGetAccessToken((token1, expiry1))
    metadata.ExpectGetAccessToken((token2, expiry2))

    credentials = gcompute_auto_auth.Credentials(
        metadata, 'default', [SCOPE1, SCOPE2])
    self.assertTrue(SCOPE1 in credentials.available_scopes)
    self.assertTrue(SCOPE2 in credentials.available_scopes)
    self.assertEquals(2, len(credentials.available_scopes))
    self.assertEquals(token1, credentials.access_token)
    self.assertEquals(expiry1, credentials.token_expiry)

    credentials._refresh(None)
    self.assertEquals(token2, credentials.access_token)
    self.assertEquals(expiry2, credentials.token_expiry)

    self.assertFalse(metadata.ExpectsMoreCalls())

  def testWithNoComputeScope(self):
    metadata = metadata_lib_test_utils.MockMetadata()
    metadata.ExpectGetAccessScopes([SCOPE2])

    success = False
    try:
      credentials = gcompute_auto_auth.Credentials(
          metadata, 'default', [SCOPE2])
    except gcompute_auto_auth.CredentialsNotPresentError:
      success = True
    self.assertTrue(success, 'Failed to throw exception without compute scope')


if __name__ == '__main__':
  unittest.main()
