#!/usr/bin/env python
#
# Copyright 2010 Google Inc. All Rights Reserved.
#

"""Setup script for the Google Compute command-line tool."""



import sys

from gcompute import version
try:
  from setuptools import setup
  print 'Loaded setuptools'
except ImportError:
  from distutils.core import setup
  print 'Loaded distutils.core'


PACKAGE_NAME = 'google-compute-client'
INSTALL_REQUIRES = ['google-apputils==0.3.0',
                    'google-api-python-client==1.0beta4',
                    'httplib2==0.7.4',
                    'iso8601==0.1.4',
                    'prettytable==0.5',
                    'python-gflags==2.0',
                    'simplejson==2.5.0']
# Sadly, version 1.5 of oauth2 requires Python 2.6 or higher, so we have to
# check for that if the user is running an earlier version of Python
(major_version, minor_version) = sys.version_info[:2]
if major_version == 2 and minor_version < 6:
  INSTALL_REQUIRES.append('oauth2==1.2')
else:
  INSTALL_REQUIRES.append('oauth2')

setup(name=PACKAGE_NAME,
      version=version.__version__,
      description='Google Compute command line tool',
      author='Google Inc.',
      author_email='gc-team@google.com',
      url='http://code.google.com/p/google-compute-client/',
      install_requires=INSTALL_REQUIRES,
      packages=['gcompute'],
      package_data={'gcompute': [
          'compute/v1beta10.json',
          'compute/v1beta11.json',
          ]},
      scripts=['gcompute/gcompute'],
      license='Apache 2.0',
      keywords='google compute client',
      classifiers=['Development Status :: 3 - Alpha',
                   'Intended Audience :: Developers',
                   'License :: OSI Approved :: Apache Software License',
                   'Operating System :: POSIX',
                   'Topic :: Internet :: WWW/HTTP'])
